import React, { useState, useEffect } from 'react';
import { CurriculumBook, BookCategory, GradeType, SemesterType } from '../types';
import { X, Plus, Trash2, Edit2, Check, BookOpen, Settings, ArrowUp, ArrowDown } from 'lucide-react';

interface CurriculumModalProps {
  isOpen: boolean;
  onClose: () => void;
  books: CurriculumBook[];
  categories: BookCategory[];
  onSaveBook: (book: CurriculumBook) => Promise<void>;
  onDeleteBook: (id: string) => Promise<void>;
  onSaveCategories: (
    newCategories: BookCategory[],
    renameMap?: { [oldName: string]: string },
    deleteList?: string[]
  ) => Promise<void>;
}

export default function CurriculumModal({
  isOpen,
  onClose,
  books,
  categories,
  onSaveBook,
  onDeleteBook,
  onSaveCategories
}: CurriculumModalProps) {
  const [selectedGrade, setSelectedGrade] = useState<GradeType | '전체'>('3학년');
  const [selectedCategory, setSelectedCategory] = useState<BookCategory | '전체'>('전체');

  // 편집용 상태
  const [editingBookId, setEditingBookId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editCategory, setEditCategory] = useState<BookCategory>('개념');
  const [editGrade, setEditGrade] = useState<GradeType>('3학년');
  const [editSemester, setEditSemester] = useState<SemesterType>('1학기');
  const [editUnitsText, setEditUnitsText] = useState('');

  // 새 교재 폼 상태
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [newName, setNewName] = useState('');
  const [newCategory, setNewCategory] = useState<BookCategory>('부교재');
  const [newGrade, setNewGrade] = useState<GradeType>('3학년');
  const [newSemester, setNewSemester] = useState<SemesterType>('1학기');
  const [newUnitsText, setNewUnitsText] = useState(
    "1단원\n2단원\n3단원\n4단원\n5단원\n6단원"
  );

  // 대분류 편집기 상태
  const [isManagingCategories, setIsManagingCategories] = useState(false);
  const [newCategoryInput, setNewCategoryInput] = useState('');
  const [editingCatIndex, setEditingCatIndex] = useState<number | null>(null);
  const [editingCatValue, setEditingCatValue] = useState<string>('');

  // 인라인 삭제 확인 상태
  const [deletingBookId, setDeletingBookId] = useState<string | null>(null);
  const [deletingCatName, setDeletingCatName] = useState<string | null>(null);

  useEffect(() => {
    if (categories && categories.length > 0) {
      if (!categories.includes(editCategory)) {
        setEditCategory(categories[0]);
      }
      if (!categories.includes(newCategory)) {
        setNewCategory(categories[0]);
      }
    }
  }, [categories]);

  const handleAddCategory = async () => {
    const trimmed = newCategoryInput.trim();
    if (!trimmed) return;
    if (categories.includes(trimmed)) {
      alert("이미 존재하는 분류명입니다.");
      return;
    }
    const nextCategories = [...categories, trimmed];
    await onSaveCategories(nextCategories, {}, []);
    setNewCategoryInput('');
  };

  const handleRenameCategory = async (oldName: string, newName: string) => {
    const trimmed = newName.trim();
    if (!trimmed || trimmed === oldName) return;
    if (categories.includes(trimmed)) {
      alert("이미 동명의 분류가 존재합니다.");
      return;
    }
    const nextCategories = categories.map(c => c === oldName ? trimmed : c);
    const renameMap = { [oldName]: trimmed };
    await onSaveCategories(nextCategories, renameMap, []);
  };

  const handleDeleteCategory = async (catToDelete: string) => {
    const nextCategories = categories.filter(c => c !== catToDelete);
    await onSaveCategories(nextCategories, {}, [catToDelete]);
    
    // 만약 선택된 카테고리가 삭제된 경우 '전체'로 복구
    if (selectedCategory === catToDelete) {
      setSelectedCategory('전체');
    }
    setDeletingCatName(null);
  };

  const handleMoveCategory = async (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === categories.length - 1) return;
    
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    const nextCategories = [...categories];
    
    // Swap the elements
    const temp = nextCategories[index];
    nextCategories[index] = nextCategories[targetIndex];
    nextCategories[targetIndex] = temp;
    
    await onSaveCategories(nextCategories, {}, []);
  };

  if (!isOpen) return null;

  // 필터링된 도서 목록
  const filteredBooks = books.filter(b => {
    const gradeMatch = selectedGrade === '전체' || b.grade === selectedGrade;
    const categoryMatch = selectedCategory === '전체' || b.category === selectedCategory;
    return gradeMatch && categoryMatch;
  });

  // 교재 추가 처리
  const handleAddNew = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return alert("교재명을 입력해주세요.");

    const units = newUnitsText
      .split('\n')
      .map(u => u.trim())
      .filter(u => u.length > 0);

    const newBook: CurriculumBook = {
      id: `custom-book-${Date.now()}`,
      name: newName,
      category: newCategory,
      grade: newGrade,
      semester: newSemester,
      units,
      isCustom: true
    };

    try {
      await onSaveBook(newBook);
      // Reset
      setNewName('');
      setNewUnitsText("1단원\n2단원\n3단원\n4단원\n5단원\n6단원");
      setIsAddingNew(false);
    } catch (err) {
      alert("교재 저장 중 오류가 발생했습니다.");
    }
  };

  // 교재 편집 시작
  const startEdit = (book: CurriculumBook) => {
    setEditingBookId(book.id);
    setEditName(book.name);
    setEditCategory(book.category);
    setEditGrade(book.grade);
    setEditSemester(book.semester);
    setEditUnitsText(book.units.join('\n'));
  };

  // 교재 편집 저장
  const handleSaveEdit = async (bookId: string) => {
    if (!editName.trim()) return alert("교재명을 입력해주세요.");

    const units = editUnitsText
      .split('\n')
      .map(u => u.trim())
      .filter(u => u.length > 0);

    const targetBook = books.find(b => b.id === bookId);
    if (!targetBook) return;

    const updatedBook: CurriculumBook = {
      ...targetBook,
      name: editName,
      category: editCategory,
      grade: editGrade,
      semester: editSemester,
      units
    };

    try {
      await onSaveBook(updatedBook);
      setEditingBookId(null);
    } catch (err) {
      alert("교재 수정 중 오류가 발생했습니다.");
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-5xl h-[85vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-50 border border-indigo-100 rounded-xl">
              <BookOpen className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-800">교재 및 커리큘럼 편집기</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                학년별 기본 교재 및 부교재 구성을 수정, 추가, 삭제할 수 있습니다.
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-hidden flex flex-col lg:flex-row">
          
          {/* Left panel: Filters & Book List */}
          <div className="flex-1 p-6 overflow-y-auto border-r border-slate-100 flex flex-col gap-4">
            
            {/* Filter buttons */}
            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">학년 구분</label>
                <div className="flex flex-wrap gap-1.5 mt-1.5">
                  {(['전체', '1학년', '2학년', '3학년', '4학년', '5학년', '6학년'] as const).map(g => (
                    <button
                      key={g}
                      onClick={() => setSelectedGrade(g)}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                        selectedGrade === g
                          ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm'
                          : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">교재 대분류</label>
                  <button
                    type="button"
                    onClick={() => setIsManagingCategories(!isManagingCategories)}
                    className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 transition-colors flex items-center gap-1 cursor-pointer border border-slate-200/40 bg-white shadow-sm hover:bg-slate-50 px-2 py-0.5 rounded-lg"
                  >
                    <Settings className="w-3 h-3 text-indigo-500" />
                    대분류 관리
                  </button>
                </div>
                {isManagingCategories && (
                  <div className="mt-2.5 p-3.5 bg-slate-100/70 border border-slate-200/60 rounded-xl space-y-2.5 animate-in fade-in slide-in-from-top-2 duration-150 mb-3 text-left">
                    <div className="flex items-center justify-between pb-1 border-b border-slate-200/40">
                      <span className="text-[10px] font-bold text-slate-700">대분류 구성 편집기</span>
                      <span className="text-[9px] text-slate-400">교사단원 및 교재 분류에 즉시 마킹됩니다.</span>
                    </div>

                    <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
                      {categories.map((cat, idx) => {
                        const isEditingThis = editingCatIndex === idx;

                        return (
                          <div key={idx} className="flex items-center gap-1.5 bg-white p-1 rounded-lg border border-slate-100 shadow-sm">
                            {isEditingThis ? (
                              <>
                                <input
                                  type="text"
                                  value={editingCatValue}
                                  onChange={(e) => setEditingCatValue(e.target.value)}
                                  className="flex-1 px-2.5 py-1 text-xs font-bold border border-indigo-500 rounded-lg bg-white focus:outline-indigo-500"
                                  autoFocus
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      e.preventDefault();
                                      const trimmed = editingCatValue.trim();
                                      if (trimmed && trimmed !== cat) {
                                        handleRenameCategory(cat, trimmed);
                                      }
                                      setEditingCatIndex(null);
                                    } else if (e.key === 'Escape') {
                                      setEditingCatIndex(null);
                                    }
                                  }}
                                />
                                <button
                                  type="button"
                                  onClick={async () => {
                                    const trimmed = editingCatValue.trim();
                                    if (trimmed && trimmed !== cat) {
                                      await handleRenameCategory(cat, trimmed);
                                    }
                                    setEditingCatIndex(null);
                                  }}
                                  className="p-1 text-emerald-600 hover:bg-emerald-50 rounded border border-transparent hover:border-slate-200 cursor-pointer"
                                  title="저장"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setEditingCatIndex(null)}
                                  className="p-1 text-slate-400 hover:bg-slate-50 rounded border border-transparent hover:border-slate-200 cursor-pointer"
                                  title="취소"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </>
                            ) : deletingCatName === cat ? (
                              <div className="flex items-center gap-1 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-150 shrink-0">
                                <span className="text-[10px] font-bold text-rose-600">삭제?</span>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteCategory(cat)}
                                  className="px-1.5 py-0.5 bg-rose-600 text-white rounded text-[10px] font-bold hover:bg-rose-700 cursor-pointer"
                                >
                                  예
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setDeletingCatName(null)}
                                  className="px-1.5 py-0.5 bg-slate-200 text-slate-700 rounded text-[10px] font-medium hover:bg-slate-300 cursor-pointer"
                                >
                                  아니오
                                </button>
                              </div>
                            ) : (
                              <>
                                <span className="flex-1 px-2.5 py-1 text-xs font-bold text-slate-700 truncate">
                                  {cat}
                                </span>
                                
                                <button
                                  type="button"
                                  disabled={idx === 0}
                                  onClick={() => handleMoveCategory(idx, 'up')}
                                  className="p-1 text-slate-400 hover:text-indigo-600 disabled:opacity-20 disabled:hover:text-slate-400 rounded cursor-pointer"
                                  title="위로 이동"
                                >
                                  <ArrowUp className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  disabled={idx === categories.length - 1}
                                  onClick={() => handleMoveCategory(idx, 'down')}
                                  className="p-1 text-slate-400 hover:text-indigo-600 disabled:opacity-20 disabled:hover:text-slate-400 rounded cursor-pointer"
                                  title="아래로 이동"
                                >
                                  <ArrowDown className="w-3.5 h-3.5" />
                                </button>

                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingCatIndex(idx);
                                    setEditingCatValue(cat);
                                  }}
                                  className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-50 rounded cursor-pointer"
                                  title="대분류명 수정"
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setDeletingCatName(cat)}
                                  className="p-1 text-slate-400 hover:text-rose-600 hover:bg-slate-50 rounded cursor-pointer"
                                  title="대분류 삭제"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    <div className="flex items-center gap-1.5 pt-2 border-t border-slate-200/30">
                      <input
                        type="text"
                        placeholder="새 대분류 (예: 심화)"
                        value={newCategoryInput}
                        onChange={(e) => setNewCategoryInput(e.target.value)}
                        className="flex-1 px-2.5 py-1 text-xs border border-slate-200 rounded-lg bg-white focus:outline-indigo-550 font-semibold"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddCategory();
                          }
                        }}
                      />
                      <button
                        type="button"
                        onClick={handleAddCategory}
                        className="py-1 px-3 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg cursor-pointer transition-all active:scale-95 flex items-center gap-0.5"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        추가
                      </button>
                    </div>
                  </div>
                )}
                <div className="flex flex-wrap gap-1.5 mt-1.5">
                  {(['전체', ...categories] as const).map(cat => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                        selectedCategory === cat
                          ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm font-bold'
                          : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* List header / Add trigger */}
            <div className="flex items-center justify-between border-t border-slate-100 pt-4 mt-2">
              <span className="text-xs font-medium text-slate-500">
                조회된 교재 <b className="text-indigo-600">{filteredBooks.length}</b>개
              </span>
              {!isAddingNew && (
                <button
                  onClick={() => setIsAddingNew(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-indigo-50 text-indigo-600 rounded-lg hover:bg-indigo-100 transition-all cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  새 교재 추가
                </button>
              )}
            </div>

            {/* Main book loop */}
            <div className="space-y-3 flex-1">
              {filteredBooks.length === 0 ? (
                <div className="text-center py-12 border-2 border-dashed border-slate-100 rounded-xl">
                  <BookOpen className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-slate-500 text-sm">해당 조건의 등록 교재가 없습니다.</p>
                </div>
              ) : (
                filteredBooks.map(book => {
                  const isEditing = editingBookId === book.id;

                  return (
                    <div 
                      key={book.id}
                      className={`p-4 rounded-xl border transition-all ${
                        isEditing 
                          ? 'border-indigo-500 bg-indigo-50/20 shadow-md ring-2 ring-indigo-500/10'
                          : 'border-slate-100 bg-slate-50/50 hover:bg-slate-50 hover:border-slate-200'
                      }`}
                    >
                      {isEditing ? (
                        <div className="space-y-3">
                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="text-slate-500 text-[11px] font-medium">교재명</label>
                              <input
                                type="text"
                                value={editName}
                                onChange={(e) => setEditName(e.target.value)}
                                className="w-full mt-1 px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-indigo-500 bg-white"
                              />
                            </div>
                            <div>
                              <label className="text-slate-500 text-[11px] font-medium">교재 분류</label>
                              <select
                                value={editCategory}
                                onChange={(e) => setEditCategory(e.target.value as BookCategory)}
                                className="w-full mt-1 px-3 py-1.5 border border-slate-200 rounded-lg text-xs bg-white"
                              >
                                {categories.map(c => (
                                  <option key={c} value={c}>{c}</option>
                                ))}
                              </select>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="text-slate-500 text-[11px] font-medium">대상 학년</label>
                              <select
                                value={editGrade}
                                onChange={(e) => setEditGrade(e.target.value as GradeType)}
                                className="w-full mt-1 px-3 py-1.5 border border-slate-200 rounded-lg text-xs bg-white"
                              >
                                {['1학년', '2학년', '3학년', '4학년', '5학년', '6학년'].map(g => (
                                  <option key={g} value={g}>{g}</option>
                                ))}
                              </select>
                            </div>
                            <div>
                              <label className="text-slate-500 text-[11px] font-medium">학기</label>
                              <select
                                value={editSemester}
                                onChange={(e) => setEditSemester(e.target.value as SemesterType)}
                                className="w-full mt-1 px-3 py-1.5 border border-slate-200 rounded-lg text-xs bg-white"
                              >
                                <option value="1학기">1학기</option>
                                <option value="2학기">2학기</option>
                              </select>
                            </div>
                          </div>

                          <div>
                            <label className="text-slate-500 text-[11px] font-medium">단원 목록 (한 줄에 한 단원씩기재)</label>
                            <textarea
                              value={editUnitsText}
                              onChange={(e) => setEditUnitsText(e.target.value)}
                              rows={4}
                              className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono bg-white focus:outline-indigo-500"
                              placeholder="예) 1. 덧셈과 뺄셈"
                            />
                          </div>

                          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                            <button
                              onClick={() => setEditingBookId(null)}
                              className="px-3 py-1.5 text-xs text-slate-500 hover:bg-slate-100 rounded-lg transition-all"
                            >
                              취소
                            </button>
                            <button
                              onClick={() => handleSaveEdit(book.id)}
                              className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-bold bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-all"
                            >
                              <Check className="w-3.5 h-3.5" />
                              저장완료
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-start justify-between gap-4">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-sm text-slate-800">{book.name}</span>
                              <span className="px-1.5 py-0.5 text-[10px] font-bold bg-emerald-50 text-emerald-600 border border-emerald-100 rounded">
                                {book.category}
                              </span>
                              <span className="px-1.5 py-0.5 text-[10px] font-bold bg-indigo-50 text-indigo-600 border border-indigo-100 rounded">
                                {book.grade} ({book.semester})
                              </span>
                            </div>
                            <p className="text-xs text-slate-500 font-mono leading-relaxed max-w-xl">
                              단원: {book.units.join(' ➔ ')}
                            </p>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0">
                            {deletingBookId === book.id ? (
                              <div className="flex items-center gap-1.5 bg-rose-50 px-2 py-1 rounded-lg border border-rose-150 animate-in fade-in zoom-in-95 duration-100">
                                <span className="text-[11px] font-bold text-rose-600 sm:inline hidden">삭제할까요?</span>
                                <button
                                  onClick={async () => {
                                    try {
                                      await onDeleteBook(book.id);
                                    } finally {
                                      setDeletingBookId(null);
                                    }
                                  }}
                                  className="px-2 py-1 bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold rounded shadow-sm transition-all cursor-pointer"
                                >
                                  삭제
                                </button>
                                <button
                                  onClick={() => setDeletingBookId(null)}
                                  className="px-2 py-1 bg-slate-200 text-slate-700 hover:bg-slate-300 text-[11px] font-semibold rounded transition-all cursor-pointer"
                                >
                                  취소
                                </button>
                              </div>
                            ) : (
                              <>
                                <button
                                  onClick={() => startEdit(book)}
                                  className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-white rounded border border-transparent hover:border-slate-200 transition-all cursor-pointer"
                                  title="수정"
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => setDeletingBookId(book.id)}
                                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-white rounded border border-transparent hover:border-slate-200 transition-all cursor-pointer"
                                  title="삭제"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Right panel: Add New Book Form */}
          {isAddingNew && (
            <div className="w-full lg:w-96 p-6 border-t lg:border-t-0 bg-slate-50/50 overflow-y-auto animate-in slide-in-from-right duration-150">
              <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
                <span className="font-bold text-slate-700 text-sm">새 교재 구성 추가 등록</span>
                <button 
                  onClick={() => setIsAddingNew(false)}
                  className="text-slate-400 hover:text-slate-600 text-xs flex items-center gap-0.5"
                >
                  <X className="w-3.5 h-3.5" /> 닫기
                </button>
              </div>

              <form onSubmit={handleAddNew} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">교재 이름</label>
                  <input
                    type="text"
                    required
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="예) 문해길 3-1, 수학의 힘 심화"
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-semibold bg-white focus:outline-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">교재 분류</label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {categories.map(cat => (
                      <button
                        type="button"
                        key={cat}
                        onClick={() => setNewCategory(cat)}
                        className={`py-1.5 rounded-lg text-xs font-medium border text-center transition-all ${
                          newCategory === cat
                            ? 'bg-indigo-600 border-indigo-600 text-white font-bold'
                            : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">대상 학년</label>
                    <select
                      value={newGrade}
                      onChange={(e) => setNewGrade(e.target.value as GradeType)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs bg-white"
                    >
                      {['1학년', '2학년', '3학년', '4학년', '5학년', '6학년'].map(g => (
                        <option key={g} value={g}>{g}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">진행 학기</label>
                    <select
                      value={newSemester}
                      onChange={(e) => setNewSemester(e.target.value as SemesterType)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs bg-white"
                    >
                      <option value="1학기">1학기</option>
                      <option value="2학기">2학기</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">
                    단원/권 구성 (한 줄당 항목 1개)
                  </label>
                  <span className="text-[10px] text-slate-400 block mb-1">
                    오프라인 진도표처럼 가로로 나열될 단원들의 명칭입니다.
                  </span>
                  <textarea
                    rows={8}
                    required
                    value={newUnitsText}
                    onChange={(e) => setNewUnitsText(e.target.value)}
                    placeholder="예)&#10;1. 9까지의 수&#10;2. 여러 가지 모양&#10;3. 덧셈과 뺄셈"
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-mono bg-white focus:outline-indigo-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition-all shadow-md active:scale-95 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  교재 생성 완료
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
