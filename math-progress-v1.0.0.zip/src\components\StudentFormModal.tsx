import React, { useState, useEffect } from 'react';
import { Student, GradeType, BookCategory, CategoryProgress } from '../types';
import { X, UserPlus, Check, Trash2 } from 'lucide-react';

interface StudentFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: Student | null; // null이면 추가, 존재하면 수정
  categories?: BookCategory[];
  onSave: (student: Student) => Promise<boolean>;
  onDelete?: (id: string) => Promise<void>;
}

export default function StudentFormModal({
  isOpen,
  onClose,
  student,
  categories = ["연산", "원리", "개념", "유형", "심화", "기타", "부교재"],
  onSave,
  onDelete
}: StudentFormModalProps) {
  const [school, setSchool] = useState('');
  const [grade, setGrade] = useState<GradeType>('3학년');
  const [name, setName] = useState('');
  const [pastHistory, setPastHistory] = useState('');
  const [isConfirmingDelete, setIsConfirmingDelete] = useState(false);

  useEffect(() => {
    setIsConfirmingDelete(false);
    if (student) {
      setSchool(student.school);
      setGrade(student.grade);
      setName(student.name);
      setPastHistory(student.pastHistory || '');
    } else {
      setSchool('');
      setGrade('3학년');
      setName('');
      setPastHistory('');
    }
  }, [student, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return alert("학생 이름을 입력해주세요.");
    if (!school.trim()) return alert("학교 명칭을 입력해주세요.");

    const initialProgress: { [category: string]: CategoryProgress } = {};
    categories.forEach(cat => {
      if (cat === "기타") {
        initialProgress[cat] = { bookId: "custom", customBookName: "", completedUnits: {} };
      } else {
        initialProgress[cat] = { bookId: "none", completedUnits: {} };
      }
    });

    const updatedStudent: Student = {
      id: student ? student.id : `student-${Date.now()}`,
      school,
      grade,
      name,
      pastHistory,
      progress: student ? student.progress : initialProgress
    };

    const success = await onSave(updatedStudent);
    if (success) {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <UserPlus className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-800 text-lg">
              {student ? '학생 정보 상세 관리' : '신규 원생 간편 입학 등록'}
            </h3>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 hover:bg-slate-150 text-slate-400 hover:text-slate-600 rounded-lg transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-1.5">이름</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="예) 홍길동"
              className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm font-semibold bg-white focus:outline-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-1.5">대상 학년</label>
              <select
                value={grade}
                onChange={(e) => setGrade(e.target.value as GradeType)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm font-semibold bg-white focus:outline-indigo-500"
              >
                {['1학년', '2학년', '3학년', '4학년', '5학년', '6학년'].map(g => (
                  <option key={g} value={g}>{g}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-1.5">학교명</label>
              <input
                type="text"
                required
                value={school}
                onChange={(e) => setSchool(e.target.value)}
                placeholder="예) ○○초등학교"
                className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm font-semibold bg-white focus:outline-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-1.5">
              과거 학습 이력 / 특이 사항
            </label>
            <textarea
              value={pastHistory}
              onChange={(e) => setPastHistory(e.target.value)}
              placeholder="예) 디딤돌 기본 완료, 연산 보충 필요 등"
              rows={3}
              className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm bg-white focus:outline-indigo-500"
            />
          </div>

          {/* Action Footer */}
          <div className="pt-4 border-t border-slate-100 mt-6 space-y-4">
            {isConfirmingDelete ? (
              <div className="bg-rose-50 border border-rose-150 rounded-xl p-3.5 space-y-2.5 animate-in slide-in-from-top-2 duration-150">
                <p className="text-xs font-bold text-rose-700 leading-relaxed">
                  정말로 '{name}' 학생의 모든 학업 진도 데이터를 영구 삭제하시겠습니까? 이 작업은 절대 되돌릴 수 없으며, 공부했던 이력이 전부 지워집니다.
                </p>
                <div className="flex gap-2 justify-end">
                  <button
                    type="button"
                    onClick={() => setIsConfirmingDelete(false)}
                    className="px-3 py-1.5 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-bold rounded-lg transition-colors cursor-pointer"
                  >
                    아니오, 취소
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      if (student && onDelete) {
                        await onDelete(student.id);
                        onClose();
                      }
                    }}
                    className="px-3 py-1.5 bg-rose-600 text-white hover:bg-rose-700 text-xs font-black rounded-lg shadow-sm transition-colors cursor-pointer"
                  >
                    예, 영구 삭제
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                {student && onDelete ? (
                  <button
                    type="button"
                    onClick={() => setIsConfirmingDelete(true)}
                    className="inline-flex items-center gap-1.5 text-xs text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 px-3 py-2 rounded-xl transition-all font-medium cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    원생 삭제
                  </button>
                ) : (
                  <div />
                )}

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-xl text-xs font-bold transition-all"
                  >
                    취소
                  </button>
                  <button
                    type="submit"
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs transition-all shadow-md active:scale-95 cursor-pointer"
                  >
                    <Check className="w-4 h-4" />
                    {student ? '수정 완료' : '등록 생성'}
                  </button>
                </div>
              </div>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}
