import { useState } from 'react';
import { Student, CurriculumBook, BookCategory, GradeType, CategoryProgress } from '../types';
import { Layers, Plus, Filter, User, HelpCircle, Edit3, Settings, BookOpen, GraduationCap, X, Check, ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface StudentTableProps {
  students: Student[];
  books: CurriculumBook[];
  categories: BookCategory[];
  onOpenProgress: (student: Student, category: BookCategory) => void;
  onOpenStudentForm: (student: Student | null) => void;
  onOpenCurriculum: () => void;
  onSaveStudent: (student: Student) => Promise<boolean>;
}

export const isMultiVolumeBook = (b: CurriculumBook): boolean => {
  if (!b || !b.units || b.units.length === 0) return false;
  if (b.id?.startsWith("custom_") || b.id === "custom" || b.isCustom) return false;
  const firstUnit = b.units[0];
  if (firstUnit.startsWith("1단원") || firstUnit.startsWith("1. ")) return false;
  return true;
};

export const getUnlearnedItems = (student: Student, books: CurriculumBook[]) => {
  // 타 카테고리는 현재 학년만, 연산은 모든 학년 교재를 체크합니다.
  const targetBooks = books.filter(b => {
    if (b.category === '연산') {
      return true; // 연산 영역은 전체 학년 대상
    }
    return b.grade === student.grade; // 그 외는 현재 학년만 대상
  });

  const unlearnedItems: Array<{
    id: string; // b.id 또는 b.id::unitName
    book: CurriculumBook;
    unitName?: string;
    name: string;
    semester: string;
    category: BookCategory;
    isCurrentGrade: boolean; // 현재 학년인지의 여부
  }> = [];

  targetBooks.forEach(b => {
    const prog = student.progress[b.category] || { bookId: 'none', completedUnits: {} };
    const isActiveBook = prog.bookId === b.id;
    const isCurrent = b.grade === student.grade;

    const treatAsIndividualUnits = b.category === '개념' || b.category === '유형' || b.category === '심화' || isMultiVolumeBook(b);

    if (treatAsIndividualUnits) {
      b.units.forEach(unit => {
        let isCompleted = false;
        if (isActiveBook) {
          isCompleted = prog.completedUnits[unit] === true;
        } else {
          // 이전에 학습 완료하여 history에 보관되었는지 확인
          const historyRecord = prog.history?.[b.id];
          if (historyRecord) {
            isCompleted = historyRecord.completedUnits[unit] === true;
          }
        }

        if (!isCompleted) {
          const formattedName = b.category === '연산'
            ? (isCurrent ? unit : `${unit} (${b.grade})`)
            : `[${b.semester}] ${b.name} - ${unit}`;

          unlearnedItems.push({
            id: `${b.id}::${unit}`,
            book: b,
            unitName: unit,
            name: formattedName,
            semester: b.semester,
            category: b.category,
            isCurrentGrade: isCurrent
          });
        }
      });
    } else {
      let isCompleted = false;
      if (isActiveBook) {
        isCompleted = true;
      } else {
        const historyRecord = prog.history?.[b.id];
        if (historyRecord) {
          const units = b.units;
          const completedCount = Object.values(historyRecord.completedUnits || {}).filter(v => v === true).length;
          if (completedCount >= units.length && units.length > 0) {
            isCompleted = true;
          }
        }
      }

      if (!isCompleted) {
        const formattedName = b.category === '연산'
          ? (isCurrent ? b.name : `${b.name} (${b.grade})`)
          : `[${b.semester}] ${b.name}`;

        unlearnedItems.push({
          id: b.id,
          book: b,
          name: formattedName,
          semester: b.semester,
          category: b.category,
          isCurrentGrade: isCurrent
        });
      }
    }
  });

  // 정렬 정책:
  // 1. 현재 학년 교재 (isCurrentGrade === true) 권장이 가장 앞에 옵니다.
  // 2. 그 외의 교재는 학년 오름차순 (1학년 -> 2학년 -> 3학년 -> 4학년 -> 5학년 -> 6학년) 순서로 정렬합니다.
  const gradeOrder = ["1학년", "2학년", "3학년", "4학년", "5학년", "6학년"];
  return unlearnedItems.sort((a, b) => {
    if (a.isCurrentGrade && !b.isCurrentGrade) return -1;
    if (!a.isCurrentGrade && b.isCurrentGrade) return 1;

    const idxA = gradeOrder.indexOf(a.book.grade);
    const idxB = gradeOrder.indexOf(b.book.grade);
    if (idxA !== idxB) {
      return idxA - idxB;
    }

    return a.id.localeCompare(b.id);
  });
};

export const getShortUnitName = (unitName: string, bookName: string): string => {
  let cleaned = unitName;
  
  if (bookName) {
    const cleanBookName = bookName.replace(/[\(\)\[\]]/g, '').trim();
    if (cleaned.startsWith(bookName)) {
      cleaned = cleaned.substring(bookName.length).trim();
    } else if (cleanBookName && cleaned.replace(/[\(\)\[\]]/g, '').trim().startsWith(cleanBookName)) {
      cleaned = cleaned.replace(/[\(\)\[\]]/g, '').trim().substring(cleanBookName.length).trim();
    }
  }

  cleaned = cleaned.replace(/^[\s\-:]+/, '').trim();

  // 1. Remove branding prefixes
  const branding = ["해법계산", "원리쏙쏙", "개념특강", "유형 라이트", "유형심화", "유형완성", "유형", "개념", "원리", "기타", "부교재"];
  for (const brand of branding) {
    if (cleaned.startsWith(brand)) {
      cleaned = cleaned.substring(brand.length).trim();
      break;
    }
  }

  cleaned = cleaned.replace(/^[\s\-:]+/, '').trim();

  // 2. If it starts with digits followed by dot, e.g., "1. 9까지의 수" -> "1단원"
  const dotMatch = cleaned.match(/^(\d+)\./);
  if (dotMatch) {
    return `${dotMatch[1]}단원`;
  }

  // 3. If it starts with digits followed by "단원", e.g., "1단원..." -> "1단원"
  const danwonMatch = cleaned.match(/^(\d+)\s*단원/);
  if (danwonMatch) {
    return `${danwonMatch[1]}단원`;
  }

  // 4. If it's a long string, clean it up to maximum 8 characters
  if (cleaned.length > 8) {
    return cleaned.substring(0, 7) + '..';
  }
  return cleaned;
};

export default function StudentTable({
  students,
  books,
  categories: propCategories,
  onOpenProgress,
  onOpenStudentForm,
  onOpenCurriculum,
  onSaveStudent
}: StudentTableProps) {
  const [selectedGrade, setSelectedGrade] = useState<GradeType | '전체'>('전체');
  const [searchQuery, setSearchQuery] = useState('');
  const [unlearnedStudent, setUnlearnedStudent] = useState<Student | null>(null);

  const categories = propCategories && propCategories.length > 0
    ? propCategories
    : ['연산', '원리', '개념', '유형', '심화', '기타', '부교재'];

  const initialExpandedCats: { [cat: string]: boolean } = {};
  categories.forEach(cat => {
    initialExpandedCats[cat] = false;
  });
  const [expandedCats, setExpandedCats] = useState<{ [cat in BookCategory]?: boolean }>(initialExpandedCats);

  // 1. 학년 필터, 검색 처리 및 정렬(학년순, 이름순)
  const gradeOrder: { [key in GradeType]: number } = {
    '1학년': 1,
    '2학년': 2,
    '3학년': 3,
    '4학년': 4,
    '5학년': 5,
    '6학년': 6
  };

  const filteredStudents = students
    .filter(student => {
      const gradeMatch = selectedGrade === '전체' || student.grade === selectedGrade;
      const searchMatch = student.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          student.school.toLowerCase().includes(searchQuery.toLowerCase());
      return gradeMatch && searchMatch;
    })
    .sort((a, b) => {
      const gradeDiff = (gradeOrder[a.grade] || 0) - (gradeOrder[b.grade] || 0);
      if (gradeDiff !== 0) return gradeDiff;
      return a.name.localeCompare(b.name, 'ko');
    });

  // 카테고리별 칼라 배지 설정
  const getCategoryTheme = (cat: string) => {
    const themes: { [key: string]: { bg: string, text: string, border: string, emptyText: string } } = {
      '연산': { bg: 'bg-amber-50 hover:bg-amber-100 text-amber-700 border-amber-200/60', text: 'text-amber-800', border: 'border-amber-200', emptyText: '연산' },
      '원리': { bg: 'bg-orange-50 hover:bg-orange-100 text-orange-700 border-orange-200/60', text: 'text-orange-850', border: 'border-orange-200', emptyText: '원리' },
      '개념': { bg: 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-200/60', text: 'text-emerald-800', border: 'border-emerald-200', emptyText: '개념' },
      '유형': { bg: 'bg-sky-50 hover:bg-sky-100 text-sky-700 border-sky-200/60', text: 'text-sky-800', border: 'border-sky-200', emptyText: '유형' },
      '심화': { bg: 'bg-pink-50 hover:bg-pink-100 text-pink-700 border-pink-200/60', text: 'text-pink-800', border: 'border-pink-200', emptyText: '심화' },
      '기타': { bg: 'bg-purple-50 hover:bg-purple-100 text-purple-700 border-purple-200/60', text: 'text-purple-800', border: 'border-purple-200', emptyText: '기타' },
      '부교재': { bg: 'bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-200/60', text: 'text-rose-800', border: 'border-rose-200', emptyText: '부교재' }
    };
    return themes[cat] || { bg: 'bg-purple-50 hover:bg-purple-100 text-purple-700 border-purple-200/60', text: 'text-purple-850', border: 'border-purple-200', emptyText: cat };
  };

  // 칩 안에 표시할 영양가 있는 정보 도출기
  const renderProgressChip = (student: Student, category: BookCategory) => {
    const prog = student.progress[category];
    const theme = getCategoryTheme(category);

    const checkIfCustom = (id: string, name?: string) => {
      if (!id || id === 'none') return false;
      if (books.some(b => b.id === id)) return false;
      return id.startsWith('custom') || !!name;
    };
    const isCustomBook = checkIfCustom(prog?.bookId || '', prog?.customBookName);

    // 지정된 교재가 없는 경우
    if (!prog || prog.bookId === 'none' || (isCustomBook && !prog.customBookName)) {
      const historyList = prog?.history ? Object.values(prog.history).filter((h: any) => h.bookId !== 'none') : [];
      if (historyList.length > 0) {
        // 이미 완강했거나 공부했던 교재들이 축적보관되어 있는 경우!
        const compCount = historyList.filter((h: any) => {
          const units = h.completedUnits || {};
          const total = Object.keys(units).length;
          const completed = Object.values(units).filter(v => v === true).length;
          return total > 0 && completed === total;
        }).length;

        return (
          <button
            onClick={() => onOpenProgress(student, category)}
            className="text-[10px] px-2 py-1 text-indigo-700 bg-indigo-50/80 hover:bg-indigo-100/90 rounded-2xl border border-indigo-200/50 font-bold transition-all w-full text-center cursor-pointer active:scale-95 flex flex-col items-center justify-center gap-1 min-h-[52px] shadow-sm"
            draggable={false}
            title={`${student.name} 학생의 이전 완료/학습 교재 ${historyList.length}권의 진행 이력이 저장되어 있습니다. 클릭하여 확인하세요!`}
          >
            <span>이력 {historyList.length}</span>
            {compCount > 0 && <span className="text-[8px] bg-indigo-600 text-white font-extrabold px-1 rounded-full">{compCount}완강</span>}
          </button>
        );
      }

      return (
        <button
          onClick={() => onOpenProgress(student, category)}
          className="text-[11px] px-2.5 py-1 text-slate-400 bg-slate-50 hover:bg-slate-100 rounded-2xl border border-slate-200/40 font-medium transition-all w-full text-center hover:text-slate-600 cursor-pointer active:scale-95 min-h-[52px] flex items-center justify-center"
          draggable={false}
        >
          -
        </button>
      );
    }

    // 이름 도출
    let bookDisplayName = '';
    let totalCount = 0;
    let completedCount = 0;
    let activeUnitsList: string[] = [];

    if (isCustomBook) {
      bookDisplayName = prog.customBookName || '';
      activeUnitsList = Object.keys(prog.completedUnits || {});
      totalCount = activeUnitsList.length;
      completedCount = activeUnitsList.filter(u => prog.completedUnits[u]).length;
    } else {
      const dbBook = books.find(b => b.id === prog.bookId);
      if (dbBook) {
        bookDisplayName = dbBook.name;
        activeUnitsList = dbBook.units || [];
        totalCount = dbBook.units.length;
        completedCount = Object.keys(prog.completedUnits || {}).filter(u => prog.completedUnits[u]).length;
      } else {
        // 백업용
        bookDisplayName = prog.bookId;
      }
    }

    // 완료 여부 가공
    const isCompleted = totalCount > 0 && completedCount === totalCount;
    const progressLabel = totalCount > 0 
      ? (isCompleted ? '(완료)' : `(${completedCount}/${totalCount})`) 
      : '';

    // 다른 완료/학습 진행 기록이 누적되어 보존되고 있는지 카운트
    const historyList = prog.history ? Object.values(prog.history).filter((h: any) => h.bookId !== 'none') : [];
    const otherHistoryCount = historyList.filter((h: any) => h.bookId !== prog.bookId).length;

    // 완강(Compelete)인 경우 연한 초록 테마로 변경하여 특별 칭찬
    const chipBg = isCompleted 
      ? 'bg-emerald-100 text-emerald-800 border-emerald-300 hover:bg-emerald-250' 
      : `${theme.bg} border-slate-200/60 text-slate-800`;

    // 최근 완료된 단원 최대 3개 추출
    const completedUnitsList = activeUnitsList.filter(u => prog.completedUnits && prog.completedUnits[u] === true);
    const last3Completed = completedUnitsList.slice(-3);

    return (
      <button
        onClick={() => onOpenProgress(student, category)}
        className={`px-2.5 py-1.5 text-xs font-semibold rounded-2xl border shadow-[0_1px_2px_rgba(0,0,0,0.02)] transition-all w-full text-center flex flex-col items-center justify-center min-h-[52px] gap-1 cursor-pointer active:scale-95 relative ${chipBg}`}
        draggable={false}
        title={`${bookDisplayName} ${progressLabel} 상세 판정하기 ${otherHistoryCount > 0 ? `(기타 저장 보관 교재 ${otherHistoryCount}권 추가 존재)` : ''}`}
      >
        <div className="flex items-center justify-center gap-1 w-full truncate">
          <span className="truncate text-[11px] font-bold">{bookDisplayName}</span>
          {progressLabel && (
            <span className="opacity-80 shrink-0 text-[9px] bg-white/50 px-1 py-0.5 rounded-md font-mono font-bold">
              {progressLabel}
            </span>
          )}
        </div>

        {last3Completed.length > 0 && (
          <div className="flex items-center justify-center gap-1 w-full overflow-hidden flex-wrap shrink-0">
            {last3Completed.map((u, i) => {
              const shortName = getShortUnitName(u, bookDisplayName);
              const customColorClass = 
                isCustomBook ? 'bg-purple-500 shadow-sm' :
                category === '연산' ? 'bg-amber-500 shadow-sm' :
                category === '원리' ? 'bg-orange-500 shadow-sm' :
                category === '개념' ? 'bg-emerald-500 shadow-sm' :
                category === '유형' ? 'bg-sky-500 shadow-sm' :
                category === '심화' ? 'bg-pink-500 shadow-sm' :
                'bg-rose-500 shadow-sm';
              return (
                <span
                  key={i}
                  className={`text-[9px] px-1 py-0.5 rounded font-black text-white ${customColorClass}`}
                  title={u}
                >
                  {shortName}
                </span>
              );
            })}
          </div>
        )}

        {otherHistoryCount > 0 && (
          <span 
            className="shrink-0 text-[8px] bg-indigo-600 text-white font-extrabold px-1 rounded-full aspect-square flex items-center justify-center min-w-[14px]"
            title={`이 카테고리에 이전에 완료/진행한 교재 ${otherHistoryCount}권이 더 저장되어 보관 중입니다.`}
          >
            +{otherHistoryCount}
          </span>
        )}
      </button>
    );
  };

  const renderUnlearnedChip = (student: Student) => {
    const unlearnedItems = getUnlearnedItems(student, books);
    const count = unlearnedItems.length;

    if (count === 0) {
      return (
        <span className="text-[11px] px-2.5 py-1 text-slate-300 bg-slate-50 rounded-full border border-slate-200/40 font-medium block text-center">
          모두 진행중
        </span>
      );
    }

    return (
      <button
        onClick={() => {
          const collapsed: { [cat: string]: boolean } = {};
          categories.forEach(cat => {
            collapsed[cat] = false;
          });
          setExpandedCats(collapsed);
          setUnlearnedStudent(student);
        }}
        className="px-3 py-1.5 text-xs font-semibold rounded-full border border-slate-200/60 bg-slate-100 text-slate-700 hover:bg-slate-200 hover:text-slate-900 shadow-[0_1px_2px_rgba(0,0,0,0.02)] transition-all w-full text-center flex items-center justify-center gap-1 cursor-pointer active:scale-95"
        draggable={false}
        title={`${student.name} 학생의 미학습 교재 ${count}개 보기`}
      >
        <span className="truncate">미학습 ({count})</span>
      </button>
    );
  };

  return (
    <div className="bg-white rounded-3xl p-6 shadow-xl border border-slate-100 flex flex-col gap-6">
      
      {/* Search and Filters Hub */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        {/* Left: Search input */}
        <div className="relative max-w-sm w-full">
          <input
            type="text"
            placeholder="학생 이름 또는 학교명 검색..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-2xl text-xs font-semibold bg-white focus:outline-indigo-500 shadow-inner"
          />
          <svg className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
        </div>

        {/* Center: Grade quick filters */}
        <div className="flex flex-wrap gap-1 bg-slate-50 border border-slate-200/50 p-1 rounded-2xl">
          {(['전체', '3학년', '4학년', '5학년', '6학년'] as const).map(g => (
            <button
              key={g}
              onClick={() => setSelectedGrade(g)}
              className={`px-4 py-1.5 text-xs font-extrabold rounded-xl transition-all cursor-pointer ${
                selectedGrade === g
                  ? 'bg-white text-indigo-600 shadow-md ring-1 ring-slate-100'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {g}
            </button>
          ))}
        </div>

        {/* Right: Management actions */}
        <div className="flex gap-2">
          <button
            onClick={() => onOpenStudentForm(null)}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-md transition-all active:scale-95 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            신규 학생 등록
          </button>
          <button
            onClick={onOpenCurriculum}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-white text-slate-700 hover:text-slate-900 border border-slate-250 rounded-xl text-xs font-bold shadow-sm transition-all active:scale-95 cursor-pointer"
          >
            <Settings className="w-3.5 h-3.5 text-slate-500" />
            학년별 교재 관리
          </button>
        </div>

      </div>

      {/* Main Responsive Grid Table */}
      <div className="overflow-x-auto overflow-y-auto max-h-[680px] rounded-2xl border border-slate-100 bg-white">
        <table className="w-full border-collapse text-left text-xs min-w-[1250px]">
          <thead>
            <tr className="bg-slate-50/95 border-b border-slate-100 font-bold text-slate-500 tracking-wide">
              <th className="px-4 py-4 w-24 sticky top-0 bg-slate-50/95 backdrop-blur-sm z-10 shadow-[0_1px_0_0_rgba(226,232,240,1)]">학년</th>
              <th className="px-4 py-4 w-28 sticky top-0 bg-slate-50/95 backdrop-blur-sm z-10 shadow-[0_1px_0_0_rgba(226,232,240,1)]">이름</th>
              <th className="px-4 py-4 w-48 sticky top-0 bg-slate-50/95 backdrop-blur-sm z-10 shadow-[0_1px_0_0_rgba(226,232,240,1)]">과거 학습 이력</th>
              {categories.map(cat => (
                <th key={cat} className="px-3 py-4 w-36 text-center sticky top-0 bg-slate-50/95 backdrop-blur-sm z-10 shadow-[0_1px_0_0_rgba(226,232,240,1)]">
                  <div className="inline-flex items-center justify-center gap-1.5">
                    <span className={`w-1.5 h-1.5 rounded-full ${
                      cat === '연산' ? 'bg-amber-400' :
                      cat === '원리' ? 'bg-orange-400' :
                      cat === '개념' ? 'bg-emerald-400' :
                      cat === '유형' ? 'bg-sky-400' :
                      cat === '심화' ? 'bg-pink-400' :
                      cat === '기타' ? 'bg-purple-400' :
                      'bg-rose-400'
                    }`} />
                    {cat}
                  </div>
                </th>
              ))}
              <th className="px-3 py-4 w-36 text-center font-bold text-slate-500 sticky top-0 bg-slate-50/95 backdrop-blur-sm z-10 shadow-[0_1px_0_0_rgba(226,232,240,1)]">
                <div className="inline-flex items-center justify-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                  미학습교재
                </div>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100/60">
            {filteredStudents.length === 0 ? (
              <tr>
                <td colSpan={4 + categories.length} className="text-center py-24 text-slate-400">
                  <GraduationCap className="w-12 h-12 text-slate-200 mx-auto mb-3" />
                  등록된 한마당 학생이 없거나 필터 조건에 부합하지 않습니다.<br />
                  <span className="text-xs text-indigo-500 block mt-1 font-bold cursor-pointer hover:underline" onClick={() => { setSelectedGrade('전체'); setSearchQuery(''); }}>
                    필터 전체 해제하기
                  </span>
                </td>
              </tr>
            ) : (
              filteredStudents.map((student, idx) => (
                <tr 
                  key={student.id}
                  className="hover:bg-slate-50/40 transition-colors group align-middle"
                >
                  <td className="px-4 py-4">
                    <span className="inline-block px-2.5 py-0.5 bg-slate-100 text-slate-600 rounded-full font-bold text-[11px]">
                      {student.grade}
                    </span>
                  </td>
                  <td className="px-4 py-4">
                    <div className="flex flex-col">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-slate-800 text-sm">{student.name}</span>
                        <button
                          onClick={() => onOpenStudentForm(student)}
                          className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded transition-all cursor-pointer"
                          title="기초 학력 편집"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <span className="text-[10px] text-slate-400/90 font-medium">{student.school}</span>
                    </div>
                  </td>
                  <td className="px-4 py-4 text-slate-400 italic max-w-[200px] truncate" title={student.pastHistory}>
                    {student.pastHistory || '-'}
                  </td>
                  
                  {/* Category Progress Chips Cells */}
                  {categories.map(cat => (
                    <td key={cat} className="px-2 py-4 align-middle">
                      <div className="max-w-[130px] mx-auto">
                        {renderProgressChip(student, cat)}
                      </div>
                    </td>
                  ))}

                  {/* Unlearned Books Chip Cell */}
                  <td className="px-2 py-4 align-middle">
                    <div className="max-w-[130px] mx-auto">
                      {renderUnlearnedChip(student)}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Grid Table Guide */}
      <div className="flex items-center gap-2 text-slate-400 text-xs bg-slate-50/60 p-4 rounded-2xl border border-slate-100 font-medium">
        <HelpCircle className="w-4 h-4 text-slate-400 shrink-0" />
        <p>
          아이콘 가이드: <b>교재 칩 이름</b>은 현재 활성화된 진행 과목을 말합니다. 칩을 <b>클릭</b>하시면 교재 선택 변경과 스티커 완료판(오프라인 진도표)을 정밀하게 색칠 기입할 수 있습니다. 완료가 되면 <span className="text-emerald-500 font-bold bg-emerald-50 px-1 py-0.5 border border-emerald-150 rounded">연두색(완료) 배지</span>로 빛나게 됩니다. 오른쪽 끝 <b>미학습교재</b>를 클릭하시면, 해당 학생 학년의 미학습 교재 목록을 일목요연하게 보고할 수 있습니다.
        </p>
      </div>

      {/* Unlearned Student Books Modal Popup */}
      <AnimatePresence>
        {unlearnedStudent && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-100 flex flex-col max-h-[85vh]"
            >
              {/* Header */}
              <div className="p-6 bg-slate-950 text-white flex items-center justify-between shrink-0">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-indigo-500/20 border border-indigo-500/30 rounded-xl">
                    <BookOpen className="w-5 h-5 text-indigo-400" />
                  </div>
                  <div>
                    <h3 className="font-bold text-base text-white">
                      <span className="text-indigo-400 font-black">{unlearnedStudent.name}</span> 학생의 교재 학습 관리
                    </h3>
                    <p className="text-[10px] text-slate-400 mt-0.5 font-medium">
                      {unlearnedStudent.school} • {unlearnedStudent.grade} 권장 교재 기준 진도 조정
                    </p>
                  </div>
                </div>
                <button 
                  onClick={() => setUnlearnedStudent(null)}
                  className="p-1.5 bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white rounded-xl transition-all cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Body */}
              <div className="p-6 overflow-y-auto space-y-5 flex-1">
                <div className="text-xs text-indigo-950 bg-indigo-50/50 p-3.5 rounded-2xl border border-indigo-100/60 leading-relaxed font-semibold">
                  📌 <b>미학습 교재 목록</b>에서 특정 항목을 <b>클릭</b>하시면 아래의 <b>[학습예정 교재리스트]</b>에 즉시 등록되며, 등록된 교재는 메인화면의 [교재주문] 기능을 통해 통합 수량 집계를 지원합니다.
                </div>

                {(() => {
                  const unlearnedItems = getUnlearnedItems(unlearnedStudent, books);

                  // 토글 함수 정의
                  const handleTogglePlanned = async (itemId: string) => {
                    const currentPlanned = unlearnedStudent.plannedBookIds || [];
                    const isAlreadyPlanned = currentPlanned.includes(itemId);
                    
                    let nextPlanned: string[];
                    if (isAlreadyPlanned) {
                      nextPlanned = currentPlanned.filter(id => id !== itemId);
                    } else {
                      nextPlanned = [...currentPlanned, itemId];
                    }

                    const updated: Student = {
                      ...unlearnedStudent,
                      plannedBookIds: nextPlanned
                    };

                    await onSaveStudent(updated);
                    setUnlearnedStudent(updated);
                  };

                  const plannedItems = (unlearnedStudent.plannedBookIds || []).map(pId => {
                    const [bId, unitName] = pId.split("::");
                    const matchedBook = books.find(b => b.id === bId);
                    if (!matchedBook) return null;
                    
                    const isCurrent = matchedBook.grade === unlearnedStudent.grade;
                    const formatName = matchedBook.category === '연산'
                      ? (unitName
                          ? (isCurrent ? unitName : `${unitName} (${matchedBook.grade})`)
                          : (isCurrent ? matchedBook.name : `${matchedBook.name} (${matchedBook.grade})`)
                        )
                      : (unitName ? `[${matchedBook.semester}] ${matchedBook.name} - ${unitName}` : `[${matchedBook.semester}] ${matchedBook.name}`);

                    return {
                      id: pId,
                      book: matchedBook,
                      unitName,
                      name: formatName,
                      grade: matchedBook.grade,
                      category: matchedBook.category
                    };
                  }).filter(Boolean) as Array<{
                    id: string;
                    book: CurriculumBook;
                    unitName?: string;
                    name: string;
                    grade: string;
                    category: BookCategory;
                  }>;

                  if (unlearnedItems.length === 0) {
                    return (
                      <div className="text-center py-12 text-slate-400 text-xs">
                        🎉 이 학년의 모든 교재가 정상 학습 중이거나 등록되었습니다!
                      </div>
                    );
                  }

                  // 카테고리별 그룹화
                  const grouped: { [cat in BookCategory]?: typeof unlearnedItems } = {};
                  unlearnedItems.forEach(item => {
                    if (!grouped[item.category]) {
                      grouped[item.category] = [];
                    }
                    grouped[item.category]?.push(item);
                  });

                  return (
                    <div className="space-y-6">
                      
                      {/* 미학습 교재 영역 */}
                      <div className="space-y-3.5">
                        <div className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                          📂 미학습 교재리스트 <span className="text-[10px] bg-slate-100 text-slate-500 font-bold px-2 py-0.5 rounded-full">{unlearnedItems.length}권</span>
                        </div>
                        <div className="space-y-4">
                          {categories.map(cat => {
                            const itemsInCat = grouped[cat] || [];
                            if (itemsInCat.length === 0) return null;
                            const isExpanded = !!expandedCats[cat];
                            return (
                              <div key={cat} className="border border-slate-100 rounded-2xl overflow-hidden shadow-[0_1px_3px_rgba(0,0,0,0.02)]">
                                <button
                                  type="button"
                                  onClick={() => setExpandedCats(prev => ({ ...prev, [cat]: !prev[cat] }))}
                                  className="w-full flex items-center justify-between text-xs font-bold text-slate-700 bg-slate-50/70 hover:bg-slate-100/90 px-4 py-3 transition-colors cursor-pointer text-left active:bg-slate-100"
                                >
                                  <div className="flex items-center gap-2">
                                    <span className={`w-2.5 h-2.5 rounded-full ${
                                      cat === '연산' ? 'bg-amber-400' :
                                      cat === '원리' ? 'bg-orange-400' :
                                      cat === '개념' ? 'bg-emerald-400' :
                                      cat === '유형' ? 'bg-sky-400' :
                                      cat === '심화' ? 'bg-pink-400' :
                                      cat === '기타' ? 'bg-purple-400' :
                                      'bg-rose-400'
                                    }`} />
                                    <span>
                                      {cat}
                                    </span>
                                    <span className="text-slate-400 font-mono text-[10px] font-bold">({itemsInCat.length}권)</span>
                                  </div>
                                  <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${isExpanded ? 'rotate-180 text-slate-700' : ''}`} />
                                </button>
                                
                                {isExpanded && (
                                  <div className="grid grid-cols-1 gap-1.5 p-3 bg-white border-t border-slate-100">
                                    {itemsInCat.map(item => {
                                      const isPlanned = (unlearnedStudent.plannedBookIds || []).includes(item.id);
                                      return (
                                        <button 
                                          type="button"
                                          key={item.id} 
                                          onClick={() => handleTogglePlanned(item.id)}
                                          className={`w-full px-3.5 py-2.5 rounded-xl border transition-all flex items-center justify-between text-xs font-bold text-left cursor-pointer active:scale-99 ${
                                            isPlanned
                                              ? 'bg-indigo-50/60 border-indigo-400 shadow-sm text-indigo-700 ring-2 ring-indigo-500/15 font-extrabold'
                                              : 'bg-slate-50 hover:bg-slate-100 border-slate-200/60 text-slate-705 hover:border-slate-300'
                                          }`}
                                        >
                                          <div className="flex flex-wrap items-center gap-2">
                                            <span className="truncate">{item.name}</span>
                                            {item.category === '연산' && item.isCurrentGrade && (
                                              <span className="text-[9px] bg-amber-105 text-amber-800 border border-amber-200/50 px-1.5 py-0.5 rounded-md font-bold">
                                                추천
                                              </span>
                                            )}
                                            {isPlanned && (
                                              <span className="text-[9px] bg-indigo-600 text-white px-1.5 py-0.5 rounded-md font-extrabold flex items-center gap-0.5 shrink-0 animate-pulse">
                                                <Check className="w-2.5 h-2.5 stroke-[3]" />
                                                학습예정
                                              </span>
                                            )}
                                          </div>
                                          <span className="text-[10px] text-slate-400 font-mono font-medium bg-white px-2 py-0.5 rounded-md border border-slate-200/50 shrink-0">
                                            {item.category === '연산' ? `${item.book.grade} 연산` : item.semester}
                                          </span>
                                        </button>
                                      );
                                    })}
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* 학습예정 교재리스트 영역 */}
                      <div className="pt-5 border-t border-slate-150 space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                            📚 학습예정 교재리스트
                            <span className="text-[10px] bg-indigo-100 text-indigo-700 font-extrabold px-2 py-0.5 rounded-full">
                              총 {plannedItems.length}권 등록됨
                            </span>
                          </div>
                        </div>

                        {plannedItems.length === 0 ? (
                           <div className="text-center py-7 text-xs text-slate-405 italic bg-slate-50/50 rounded-2xl border border-dashed border-slate-200/80">
                            지정된 학습예정 교재가 없습니다.<br />
                            <span className="text-[10px] text-slate-400 mt-1 block">위 미학습 교재를 클릭하여 계획을 수립하세요!</span>
                          </div>
                        ) : (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {plannedItems.map(item => (
                              <div 
                                key={item.id}
                                className="p-3 bg-indigo-50/30 border border-indigo-200/50 rounded-2xl flex items-center justify-between text-xs font-bold"
                              >
                                <div className="truncate pr-2">
                                  <div className="text-slate-800 truncate" title={item.name}>{item.name}</div>
                                  <div className="text-[9px] text-indigo-600 font-medium mt-0.5">{item.grade} • {item.category}</div>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => handleTogglePlanned(item.id)}
                                  className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all shrink-0 cursor-pointer"
                                  title="학습예정 리스트에서 제외"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                    </div>
                  );
                })()}
              </div>

              {/* Footer */}
              <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end shrink-0">
                <button
                  onClick={() => setUnlearnedStudent(null)}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow transition-all active:scale-95 cursor-pointer"
                >
                  확인
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
