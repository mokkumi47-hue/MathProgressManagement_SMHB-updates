export type GradeType = '1학년' | '2학년' | '3학년' | '4학년' | '5학년' | '6학년';
export type SemesterType = '1학기' | '2학기';

// 교재 카테고리
export type BookCategory = string;

// 교재(Curriculum Book) 정의
export interface CurriculumBook {
  id: string;          // 고유 ID (예: "hbp-concept-3-1")
  name: string;        // 교재명 (예: "개념 3-1")
  category: BookCategory;
  grade: GradeType;
  semester: SemesterType;
  units: string[];     // 세부 단원 또는 권 목록 (예: ["1. 덧셈과 뺄셈", "2. 평면도형", ...])
  isCustom?: boolean;  // 사용자가 임의로 추가한 교재 여부
}

// 학생별 각 카테고리 진도 상태
export interface CategoryProgress {
  bookId: string;                     // 현재 진행 중인 교재 ID (비어있음: "" or "none")
  customBookName?: string;            // '기타' 카테고리 등에서 수동으로 입력하는 교재명
  completedUnits: { [unitName: string]: boolean }; // 현재 진행 중인 교재용 완료 맵
  
  // 지금까지 이 카테고리에서 진행했던 모든 교재들의 진도 상태 이력 보관소
  history?: {
    [bookId: string]: {
      bookId: string;
      customBookName?: string;
      completedUnits: { [unitName: string]: boolean };
      updatedAt?: string;
    }
  };
}

// 학생(Student) 정보 정의
export interface Student {
  id: string;
  school: string;      // 학교명 (예: "○○초등학교")
  grade: GradeType;    // 학년 (예: "3학년")
  name: string;        // 이름
  pastHistory: string; // 과거학습이력 (예: "2학년 과정 완료")
  progress: {
    [category in BookCategory]: CategoryProgress;
  };
  plannedBookIds?: string[]; // 학습예정 교재 ID 리스트
}

// 백엔드 API 응답용 래퍼 타입
export interface APIResponse<T> {
  success: boolean;
  data: T;
  message?: string;
}
