import express from "express";
import path from "path";
import fs from "fs";
import crypto from "crypto";
import { exec, spawn } from "child_process";
import { createServer as createViteServer } from "vite";
import { CurriculumBook, Student, GradeType } from "./src/types";

const app = express();
const PORT = 3000;

app.use(express.json());

// ---------------------------------------------------------------
// 로컬 JSON 파일 기반 저장소 (Firestore 제거 - 완전 오프라인 동작)
// 모든 데이터는 data/*.json 파일에 저장되며 Firebase 계정이 필요 없습니다.
// ---------------------------------------------------------------
const DATA_DIR = path.join(process.cwd(), "data");

interface LocalDoc {
  id: string;
  [key: string]: any;
}

function loadCollection(collectionName: string): LocalDoc[] {
  const filePath = path.join(DATA_DIR, `${collectionName}.json`);
  if (!fs.existsSync(filePath)) return [];
  try {
    const raw = JSON.parse(fs.readFileSync(filePath, "utf8"));
    return Array.isArray(raw) ? raw : [];
  } catch (err) {
    // 손상된 파일을 조용히 []로 처리하면 다음 시딩이 덮어써 데이터가 유실됩니다.
    // 대신 손상 파일을 .corrupt 로 백업해 두어 복구 가능성을 보존합니다.
    try {
      // 타임스탬프 접미사로 기존 백업을 덮어쓰지 않도록 보존 (복구 가능성 최대화)
      const backupPath = `${filePath}.corrupt-${Date.now()}`;
      fs.copyFileSync(filePath, backupPath);
      console.error(`[local-db] '${collectionName}.json' 읽기 실패 - 손상 파일을 '${path.basename(backupPath)}'로 백업했습니다.`, err);
    } catch {
      console.error(`[local-db] '${collectionName}.json' 읽기 실패:`, err);
    }
    return [];
  }
}

function saveCollection(collectionName: string, docs: LocalDoc[]) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const filePath = path.join(DATA_DIR, `${collectionName}.json`);
  // 원자적 쓰기: 임시 파일에 먼저 쓴 뒤 rename 하여, 쓰기 도중 중단돼도 기존 파일이 손상되지 않게 합니다.
  const tmpPath = `${filePath}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(docs, null, 2), "utf8");
  fs.renameSync(tmpPath, filePath);
}

// 로컬 JSON 파일 기반 데이터 래퍼 (db.collection().get() / doc().set() / doc().delete()).
// 아래의 모든 REST API 로직은 이 래퍼 위에서 동작합니다.
// 주의: 모든 작업(get/set/delete)마다 data/*.json 파일을 디스크에서 다시 읽어오므로,
// data()가 반환하는 객체는 작업 시점의 스냅샷 참조입니다(직접 수정 후 set()으로 저장).
const db = {
  collection(collectionPath: string) {
    return {
      async get() {
        const docs = loadCollection(collectionPath);
        return {
          empty: docs.length === 0,
          docs: docs.map((d) => ({
            ref: {
              async delete() {
                const current = loadCollection(collectionPath);
                const next = current.filter((x) => x.id !== d.id);
                saveCollection(collectionPath, next);
              }
            },
            data() {
              return d;
            }
          }))
        };
      },
      doc(docPath: string) {
        return {
          async set(data: any) {
            // Firestore 의미론과 동일하게 docPath 기준으로 저장 (data.id 강제 정규화)
            const normalized = { ...data, id: docPath };
            const current = loadCollection(collectionPath);
            const idx = current.findIndex((x) => x.id === docPath);
            if (idx >= 0) {
              current[idx] = normalized;
            } else {
              current.push(normalized);
            }
            saveCollection(collectionPath, current);
          },
          async delete() {
            const current = loadCollection(collectionPath);
            const next = current.filter((x) => x.id !== docPath);
            saveCollection(collectionPath, next);
          }
        };
      }
    };
  }
};

/**
 * Ensures initial default curriculums, sample categories & students are populated 
 * inside the local JSON data files upon first run if collections are empty.
 */
async function ensureLocalData() {
  console.log("로컬 데이터 상태 점검 및 자동 시드 배포 기동...");
  try {
    // 1. Categories seed
    const catsCol = db.collection("categories");
    const catsSnap = await catsCol.get();
    if (catsSnap.empty) {
      console.log("로컬 'categories' 컬렉션 공백 감지 - 초기 대분류 시드를 주입합니다.");
      const defaultCategories = ["연산", "원리", "개념", "유형", "심화", "기타", "부교재"];
      for (let i = 0; i < defaultCategories.length; i++) {
        const cat = defaultCategories[i];
        await catsCol.doc(cat).set({ id: cat, name: cat, order: i });
      }
    }

    // 2. Curriculum Books seed
    const currCol = db.collection("curriculum");
    const currSnap = await currCol.get();
    if (currSnap.empty) {
      console.log("로컬 'curriculum' 컬렉션 공백 감지 - 초등 전학년 명문 기본 교재 사전을 주입합니다.");
      const initialCurriculum: CurriculumBook[] = [];
      const grades: GradeType[] = ["1학년", "2학년", "3학년", "4학년", "5학년", "6학년"];

      const conceptUnits: { [key: string]: { [sem: string]: string[] } } = {
        "1학년": {
          "1학기": ["1. 9까지의 수", "2. 여러 가지 모양", "3. 덧셈과 뺄셈", "4. 비교하기", "5. 50까지의 수"],
          "2학기": ["1. 100까지의 수", "2. 덧셈과 뺄셈(1)", "3. 모양과 시각", "4. 덧셈과 뺄셈(2)", "5. 규칙찾기", "6. 덧셈과 뺄셈(3)"]
        },
        "2학년": {
          "1학기": ["1. 세자리 수", "2. 여러 가지 도형", "3. 덧셈과 뺄셈", "4. 길이 재기", "5. 분류하기", "6. 곱셈"],
          "2학기": ["1. 네 자리 수", "2. 곱셈구구", "3. 길이 재기", "4. 시각과 시간", "5. 표과 그래프", "6. 규칙 찾기"]
        },
        "3학년": {
          "1학기": ["1. 덧셈과 뺄셈", "2. 평면도형", "3. 나눗셈", "4. 곱셈", "5. 길이와 시간", "6. 분수와 소수"],
          "2학기": ["1. 곱셈", "2. 나눗셈", "3. 원", "4. 분수", "5. 들이와 무게", "6. 자료와 그림그래프"]
        },
        "4학년": {
          "1학기": ["1. 큰 수", "2. 각도", "3. 곱셈과 나눗셈", "4. 평면도형의 이동", "5. 자료와 막대그래프", "6. 규칙 찾기"],
          "2학기": ["1. 분수의 덧셈과 뺄셈", "2. 삼각형", "3. 소수의 덧셈과 밸셈", "4. 사각형", "5. 자료와 꺽은선 그래프", "6. 다각형"]
        },
        "5학년": {
          "1학기": ["1. 자연수의 혼합계산", "2. 약수와 배수", "3. 규칙과 대응", "4. 약분과 통분", "5. 분수의 덧셈과 뺄셈", "6. 다각형의 둘레와 넓이"],
          "2학기": ["1. 어림하기", "2. 분수의 곱셈", "3. 합동과 대칭", "4. 소수의 곱셈", "5. 직육면체", "6. 평균과 가능성"]
        },
        "6학년": {
          "1학기": ["1. 분수의 나눗셈", "2. 각기둥과 각뿔", "3. 소수의 나눗셈", "4. 비와 비율", "5. 자료와 여러 가지 그래프", "6. 직육면체의 겉넓이와 부피"],
          "2학기": ["1. 분수의 나눗셈", "2. 소수의 나눗셈", "3. 공간과 입체", "4. 비례식과 비례배분", "5. 원의 넓이", "6. 원기둥, 원뿔, 구"]
        }
      };

      grades.forEach(grade => {
        ["1학기", "2학기"].forEach(sem => {
          const semesterLabel = sem;
          const shortSem = sem === "1학기" ? "1" : "2";

          if (conceptUnits[grade] && conceptUnits[grade][semesterLabel]) {
            initialCurriculum.push({
              id: `hbp-concept-${grade}-${shortSem}`,
              name: `개념 ${grade[0]}-${shortSem}`,
              category: "개념",
              grade,
              semester: semesterLabel as any,
              units: conceptUnits[grade][semesterLabel]
            });

            initialCurriculum.push({
              id: `hbp-type-${grade}-${shortSem}`,
              name: `유형 ${grade[0]}-${shortSem}`,
              category: "유형",
              grade,
              semester: semesterLabel as any,
              units: conceptUnits[grade][semesterLabel]
            });
          }

          const extraGrades = ["3학년", "4학년", "5학년", "6학년"];
          if (extraGrades.includes(grade)) {
            const num = grade[0];

            initialCurriculum.push({
              id: `hbp-wonri-${grade}-${shortSem}`,
              name: `원리쏙쏙 ${num}-${shortSem}`,
              category: "원리",
              grade,
              semester: semesterLabel as any,
              units: [`원리쏙쏙 ${num}-${shortSem} 1권`, `원리쏙쏙 ${num}-${shortSem} 2권`]
            });

            initialCurriculum.push({
              id: `hbp-concept-special-${grade}-${shortSem}`,
              name: `개념특강 ${num}-${shortSem}`,
              category: "개념",
              grade,
              semester: semesterLabel as any,
              units: [`${num}-${shortSem} 개념특강1(1~3단원)`, `${num}-${shortSem} 개념특강2(4~6단원)`]
            });

            initialCurriculum.push({
              id: `hbp-type-light-${grade}-${shortSem}`,
              name: `유형 라이트 ${num}-${shortSem}`,
              category: "유형",
              grade,
              semester: semesterLabel as any,
              units: [`${num}-${shortSem} 유형라이트1(1~3단원)`, `${num}-${shortSem} 유형라이트2(4~6단원)`]
            });

            const typeCompletionUnits = Array.from({ length: 12 }, (_, i) => `${num}학년 ${shortSem}학기 ${i + 1}호`);
            initialCurriculum.push({
              id: `hbp-type-complete-${grade}-${shortSem}`,
              name: `유형완성 ${num}-${shortSem}`,
              category: "유형",
              grade,
              semester: semesterLabel as any,
              units: typeCompletionUnits
            });

            initialCurriculum.push({
              id: `hbp-type-deep-${grade}-${shortSem}`,
              name: `유형심화 ${num}-${shortSem}`,
              category: "심화",
              grade,
              semester: semesterLabel as any,
              units: [`${num}-${shortSem} 유형심화1(1~3단원)`, `${num}-${shortSem} 유형심화2(4~6단원)`]
            });
          }
        });

        if (grade === "1학년") {
          initialCurriculum.push({
            id: `hbp-calc-1`,
            name: "해법계산 A",
            category: "연산",
            grade: "1학년",
            semester: "1학기",
            units: Array.from({ length: 16 }, (_, i) => `해법계산 A${String(i + 1).padStart(2, "0")}`)
          });
        } else if (grade === "2학년") {
          initialCurriculum.push({
            id: `hbp-calc-2`,
            name: "해법계산 B",
            category: "연산",
            grade: "2학년",
            semester: "1학기",
            units: Array.from({ length: 16 }, (_, i) => `해법계산 B${String(i + 1).padStart(2, "0")}`)
          });
        } else if (grade === "3학년") {
          initialCurriculum.push({
            id: `hbp-calc-3`,
            name: "해법계산 C",
            category: "연산",
            grade: "3학년",
            semester: "1학기",
            units: Array.from({ length: 16 }, (_, i) => `해법계산 C${String(i + 1).padStart(2, "0")}`)
          });
        } else if (grade === "4학년") {
          initialCurriculum.push({
            id: `hbp-calc-4`,
            name: "해법계산 D",
            category: "연산",
            grade: "4학년",
            semester: "1학기",
            units: Array.from({ length: 16 }, (_, i) => `해법계산 D${String(i + 1).padStart(2, "0")}`)
          });
        } else if (grade === "5학년") {
          initialCurriculum.push({
            id: `hbp-calc-5`,
            name: "해법계산 E",
            category: "연산",
            grade: "5학년",
            semester: "1학기",
            units: Array.from({ length: 16 }, (_, i) => `해법계산 E${String(i + 1).padStart(2, "0")}`)
          });
        } else if (grade === "6학년") {
          initialCurriculum.push({
            id: `hbp-calc-6`,
            name: "해법계산 F",
            category: "연산",
            grade: "6학년",
            semester: "1학기",
            units: Array.from({ length: 16 }, (_, i) => `해법계산 F${String(i + 1).padStart(2, "0")}`)
          });
        }
      });

      const subBooks = ["문해길", "디딤돌기본", "썬", "수학리더기본", "수학리더유형", "수학의 힘"];
      grades.forEach(grade => {
        subBooks.forEach(book => {
          initialCurriculum.push({
            id: `sub-${book.replace(/\s+/g, "")}-${grade}-1`,
            name: `${book} ${grade[0]}-1`,
            category: "부교재",
            grade,
            semester: "1학기",
            units: ["1단원", "2단원", "3단원", "4단원", "5단원", "6단원"]
          });
          initialCurriculum.push({
            id: `sub-${book.replace(/\s+/g, "")}-${grade}-2`,
            name: `${book} ${grade[0]}-2`,
            category: "부교재",
            grade,
            semester: "2학기",
            units: ["1단원", "2단원", "3단원", "4단원", "5단원", "6단원"]
          });
        });
      });

      for (const curr of initialCurriculum) {
        await currCol.doc(curr.id).set(curr);
      }
      console.log(`로컬 'curriculum' 컬렉션에 초기 교재 사전 ${initialCurriculum.length}권 주입 완료.`);
    }

    // 3. Students: 배포 시 개인정보가 남지 않도록 샘플 학생을 주입하지 않습니다.
    //    원생 데이터는 각 학원이 직접 등록하며, data/students.json 에만 저장됩니다.

    // 4. Manual Live Migration for "유형심화" books and student progress
    console.log("로컬 데이터 '유형심화' 수동 마이그레이션 진입...");
    const currColAll = db.collection("curriculum");
    const currSnapAll = await currColAll.get();
    const deepBookIdsSet = new Set<string>();

    for (const d of currSnapAll.docs) {
      const book = d.data() as CurriculumBook;
      if (book.name && book.name.includes("유형심화")) {
        deepBookIdsSet.add(book.id);
        if (book.category === "유형") {
          console.log(`기존 교재 마이그레이션 대상 검출: ${book.name} [${book.id}]`);
          const updatedBook = { ...book, category: "심화" };
          await currColAll.doc(book.id).set(updatedBook);
        }
      }
    }

    // Now migrate student progress if they are currently studying a "유형심화" book
    const studColAll = db.collection("students");
    const studSnapAll = await studColAll.get();
    for (const d of studSnapAll.docs) {
      const student = d.data() as Student;
      let studentChanged = false;
      
      if (student.progress) {
        const typeProgress = student.progress["유형"];
        if (typeProgress && typeProgress.bookId && deepBookIdsSet.has(typeProgress.bookId)) {
          console.log(`${student.name} 학생의 '유형' 진도가 '유형심화'로 등록되어 있어, 이를 '심화' 영역으로 자동 이동합니다.`);
          
          // Copy progress to "심화" category
          student.progress["심화"] = {
            ...typeProgress
          };

          // Reset "유형" category progress to standard none
          student.progress["유형"] = {
            bookId: "none",
            completedUnits: {}
          };

          studentChanged = true;
        }
      }

      if (studentChanged) {
        await studColAll.doc(student.id).set(student);
      }
    }
    console.log("로컬 '유형심화' 마이그레이션 상태 무결점 점검 완료.");
  } catch (err) {
    console.error("로컬 초기 점검/시딩 도중 고장:", err);
  }
}

// -------------------------------------------------------------
// REST API Control Layer (로컬 JSON 파일 저장소 연동)
// -------------------------------------------------------------

// Categories API
app.get("/api/categories", async (req, res) => {
  try {
    const catsCol = db.collection("categories");
    const catsSnap = await catsCol.get();
    let docs = catsSnap.docs.map(d => d.data());

    if (docs.length === 0) {
      const defaultCategories = ["연산", "원리", "개념", "유형", "심화", "기타", "부교재"];
      for (let i = 0; i < defaultCategories.length; i++) {
        const cat = defaultCategories[i];
        await catsCol.doc(cat).set({ id: cat, name: cat, order: i });
      }
      docs = defaultCategories.map((cat, i) => ({ id: cat, name: cat, order: i }));
    }

    // Sort categories by their order parameter
    docs.sort((a, b) => {
      const orderA = typeof a.order === 'number' ? a.order : 0;
      const orderB = typeof b.order === 'number' ? b.order : 0;
      return orderA - orderB;
    });

    const categoriesList = docs.map(d => d.name as string);
    res.json({ success: true, data: categoriesList });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

app.post("/api/categories", async (req, res) => {
  try {
    const { categories, renameMap, deleteList } = req.body as {
      categories: string[];
      renameMap?: { [key: string]: string };
      deleteList?: string[];
    };

    // 1. Rewrite matching Category items inside Firestore
    const catsCol = db.collection("categories");
    const catsSnap = await catsCol.get();
    for (const d of catsSnap.docs) {
      await d.ref.delete();
    }
    for (let i = 0; i < categories.length; i++) {
      const cat = categories[i];
      await catsCol.doc(cat).set({ id: cat, name: cat, order: i });
    }

    // 2. Load all curriculum books & students to migrate categories
    const currCol = db.collection("curriculum");
    const currSnap = await currCol.get();
    let dataCurriculum = currSnap.docs.map(d => d.data() as CurriculumBook);

    const studCol = db.collection("students");
    const studSnap = await studCol.get();
    let dataStudents = studSnap.docs.map(d => d.data() as Student);

    let changed = false;

    if (renameMap && Object.keys(renameMap).length > 0) {
      changed = true;
      dataCurriculum = dataCurriculum.map(b => {
        if (renameMap[b.category]) {
          return { ...b, category: renameMap[b.category] };
        }
        return b;
      });

      dataStudents = dataStudents.map(s => {
        const nextProgress = { ...s.progress };
        Object.entries(renameMap).forEach(([oldCat, newCat]) => {
          if (nextProgress[oldCat]) {
            nextProgress[newCat] = nextProgress[oldCat];
            delete nextProgress[oldCat];
          }
        });
        return { ...s, progress: nextProgress };
      });
    }

    if (deleteList && deleteList.length > 0) {
      changed = true;
      const fallbackCat = categories.includes('기타') ? '기타' : (categories[0] || '');
      dataCurriculum = dataCurriculum.map(b => {
        if (deleteList.includes(b.category)) {
          return { ...b, category: fallbackCat };
        }
        return b;
      });

      dataStudents = dataStudents.map(s => {
        const nextProgress = { ...s.progress };
        deleteList.forEach((delCat: string) => {
          delete nextProgress[delCat];
        });
        return { ...s, progress: nextProgress };
      });
    }

    if (changed) {
      // Batch save back to Firestore
      for (const book of dataCurriculum) {
        await currCol.doc(book.id).set(book);
      }
      for (const student of dataStudents) {
        await studCol.doc(student.id).set(student);
      }
    }

    res.json({ success: true, categories, curriculum: dataCurriculum, students: dataStudents });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Curriculum API
app.get("/api/curriculum", async (req, res) => {
  try {
    const currCol = db.collection("curriculum");
    const currSnap = await currCol.get();
    const data = currSnap.docs.map(d => d.data() as CurriculumBook);
    res.json({ success: true, data });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

app.post("/api/curriculum", async (req, res) => {
  try {
    const newBook: CurriculumBook = req.body;
    if (!newBook.id || !newBook.name || !newBook.category) {
      return res.status(400).json({ success: false, message: "필수 정보가 누락되었습니다." });
    }
    const currCol = db.collection("curriculum");
    await currCol.doc(newBook.id).set(newBook);

    const currSnap = await currCol.get();
    const data = currSnap.docs.map(d => d.data() as CurriculumBook);
    res.json({ success: true, data });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

app.put("/api/curriculum/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const updatedBook: CurriculumBook = req.body;
    const currCol = db.collection("curriculum");
    await currCol.doc(id).set(updatedBook);

    const currSnap = await currCol.get();
    const data = currSnap.docs.map(d => d.data() as CurriculumBook);
    res.json({ success: true, data });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

app.delete("/api/curriculum/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const currCol = db.collection("curriculum");
    await currCol.doc(id).delete();

    const currSnap = await currCol.get();
    const data = currSnap.docs.map(d => d.data() as CurriculumBook);
    res.json({ success: true, data });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Students API
app.get("/api/students", async (req, res) => {
  try {
    const studCol = db.collection("students");
    const studSnap = await studCol.get();
    const data = studSnap.docs.map(d => d.data() as Student);
    res.json({ success: true, data });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

app.post("/api/students", async (req, res) => {
  try {
    const newStudent: Student = req.body;
    console.log("POST /api/students - Received student payload:", JSON.stringify(newStudent, null, 2));
    if (!newStudent.name || !newStudent.grade) {
      console.warn("POST /api/students - Validation failed: Missing name or grade");
      return res.status(400).json({ success: false, message: "이름과 학년은 필수 입력 사항입니다." });
    }
    const studCol = db.collection("students");
    console.log(`POST /api/students - Writing to document id: ${newStudent.id}`);
    await studCol.doc(newStudent.id).set(newStudent);
    console.log("POST /api/students - Firestore write successful");

    const studSnap = await studCol.get();
    const data = studSnap.docs.map(d => d.data() as Student);
    res.json({ success: true, data });
  } catch (err: any) {
    console.error("POST /api/students - Server error during write:", err);
    res.status(500).json({ success: false, message: err.message });
  }
});

app.put("/api/students/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const updatedStudent: Student = req.body;
    console.log(`PUT /api/students/${id} - Received payload:`, JSON.stringify(updatedStudent, null, 2));
    const studCol = db.collection("students");
    await studCol.doc(id).set(updatedStudent);
    console.log(`PUT /api/students/${id} - Firestore rewrite successful`);

    const studSnap = await studCol.get();
    const data = studSnap.docs.map(d => d.data() as Student);
    res.json({ success: true, data });
  } catch (err: any) {
    console.error(`PUT /api/students/${id} - Server error during rewrite:`, err);
    res.status(500).json({ success: false, message: err.message });
  }
});

app.delete("/api/students/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const studCol = db.collection("students");
    await studCol.doc(id).delete();

    const studSnap = await studCol.get();
    const data = studSnap.docs.map(d => d.data() as Student);
    res.json({ success: true, data });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

app.post("/api/students/complete-orders", async (req, res) => {
  try {
    const { pIds } = req.body as { pIds: string[] };
    if (!pIds || !Array.isArray(pIds)) {
      return res.status(400).json({ success: false, message: "올바르지 않은 요청 사양입니다. pIds 배열이 필요합니다." });
    }
    
    const studCol = db.collection("students");
    const studSnap = await studCol.get();
    const students = studSnap.docs.map(d => d.data() as Student);
    
    let updatedCount = 0;
    
    for (const student of students) {
      if (!student.plannedBookIds || student.plannedBookIds.length === 0) continue;
      
      const beforeLength = student.plannedBookIds.length;
      const filteredPlanned = student.plannedBookIds.filter(id => !pIds.includes(id));
      
      if (filteredPlanned.length !== beforeLength) {
        student.plannedBookIds = filteredPlanned;
        await studCol.doc(student.id).set(student);
        updatedCount++;
      }
    }
    
    if (updatedCount > 0) {
      console.log(`[bulk-complete-orders] Successfully completed orders and updated ${updatedCount} students.`);
    }
    
    const finalSnap = await studCol.get();
    const data = finalSnap.docs.map(d => d.data() as Student);
    res.json({ success: true, data });
  } catch (err: any) {
    console.error("Error during bulk complete orders:", err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// -------------------------------------------------------------
// 자동 업데이트 시스템 (GitHub 업데이트 매니페스트 기반)
// - update.config.json 의 updateUrl 에서 update.json 매니페스트를 읽어
//   최신 버전을 감지하고, 압축 파일을 내려받아 검증 후 교체·재시작합니다.
// - data/ 폴더(원생 개인정보)는 절대 건드리지 않습니다.
// -------------------------------------------------------------
const UPDATE_CONFIG_FILE = path.join(process.cwd(), "update.config.json");
const UPDATE_TMP_DIR = path.join(process.cwd(), "업데이트_임시");
const UPDATE_NEW_DIR = path.join(UPDATE_TMP_DIR, "new");
// 다운로드 완료 상태를 디스크에 기록해 두어, 서버가 재시작돼도
// 적용 대기 중인 업데이트를 잃지 않도록 합니다 (적용 성공 시 배치에서 삭제됨)
const UPDATE_STATE_FILE = path.join(UPDATE_TMP_DIR, "update-state.json");

interface UpdateConfig {
  updateUrl?: string;
}

function loadUpdateConfig(): UpdateConfig {
  try {
    return JSON.parse(fs.readFileSync(UPDATE_CONFIG_FILE, "utf8"));
  } catch {
    return {};
  }
}

function getCurrentVersion(): string {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(process.cwd(), "package.json"), "utf8"));
    return typeof pkg.version === "string" ? pkg.version : "0.0.0";
  } catch {
    return "0.0.0";
  }
}

// "v1.2.3" 접두어 허용, 숫자 세그먼트 비교
function compareVersions(a: string, b: string): number {
  const pa = a.replace(/^v/i, "").split(".").map((n) => parseInt(n, 10) || 0);
  const pb = b.replace(/^v/i, "").split(".").map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const diff = (pa[i] || 0) - (pb[i] || 0);
    if (diff !== 0) return diff;
  }
  return 0;
}

const updateState: {
  phase: "idle" | "checking" | "available" | "downloading" | "downloaded" | "applying" | "error";
  progress: number;
  error: string;
  lastCheck: {
    hasUpdate: boolean;
    currentVersion: string;
    latestVersion: string;
    notes: string;
    checkedAt: string;
  };
} = {
  phase: "idle",
  progress: 0,
  error: "",
  lastCheck: {
    hasUpdate: false,
    currentVersion: getCurrentVersion(),
    latestVersion: "",
    notes: "",
    checkedAt: "",
  },
};

interface UpdateManifest {
  version: string;
  notes?: string;
  file?: string;
  sha256?: string;
}

async function fetchUpdateManifest(): Promise<UpdateManifest | null> {
  const cfg = loadUpdateConfig();
  if (!cfg.updateUrl) return null;
  const manifestUrl = `${cfg.updateUrl.replace(/\/+$/, "")}/update.json`;
  const res = await fetch(manifestUrl, { signal: AbortSignal.timeout(15000) });
  if (res.status === 404) return null;
  if (!res.ok) throw new Error(`업데이트 매니페스트를 불러오지 못했습니다 (HTTP ${res.status})`);
  return (await res.json()) as UpdateManifest;
}

function runPowerShell(command: string): Promise<void> {
  return new Promise((resolve, reject) => {
    exec(
      `powershell -NoProfile -NonInteractive -Command "${command}"`,
      { windowsHide: true, maxBuffer: 10 * 1024 * 1024 },
      (err, stdout, stderr) => {
        if (err) reject(new Error(stderr || err.message));
        else resolve();
      }
    );
  });
}

// 압축 해제 후 경로 안전성 검증 (zip-slip 방어: 추출 파일이 대상 폴더 밖으로 나가지 않았는지 확인)
function assertSafeExtraction() {
  const root = path.resolve(UPDATE_NEW_DIR);
  const stack = [root];
  while (stack.length) {
    const dir = stack.pop()!;
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (!path.resolve(full).startsWith(root + path.sep)) {
        throw new Error("업데이트 압축 파일에 안전하지 않은 경로가 포함되어 있습니다.");
      }
      if (entry.isDirectory()) stack.push(full);
    }
  }
}

async function downloadAndExtractUpdate(): Promise<void> {
  const cfg = loadUpdateConfig();
  if (!cfg.updateUrl) throw new Error("업데이트 주소가 설정되지 않았습니다.");
  const manifest = await fetchUpdateManifest();
  if (!manifest) throw new Error("업데이트 매니페스트가 없습니다.");
  const zipUrl = `${cfg.updateUrl.replace(/\/+$/, "")}/${manifest.file || "update.zip"}`;

  fs.mkdirSync(UPDATE_TMP_DIR, { recursive: true });
  const zipPath = path.join(UPDATE_TMP_DIR, "update.zip");

  const res = await fetch(zipUrl, { signal: AbortSignal.timeout(120000) });
  if (!res.ok || !res.body) throw new Error(`업데이트 파일 다운로드 실패 (HTTP ${res.status})`);

  const total = Number(res.headers.get("content-length")) || 0;
  const hash = crypto.createHash("sha256");
  const fileStream = fs.createWriteStream(zipPath);
  const reader = res.body.getReader();
  let received = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    hash.update(value);
    received += value.length;
    if (total > 0) updateState.progress = Math.min(99, Math.round((received / total) * 100));
    fileStream.write(value);
  }
  await new Promise<void>((resolve, reject) => {
    fileStream.end(() => resolve());
    fileStream.on("error", reject);
  });

  // SHA-256 검증 (배포 도중 파일이 손상/변조되지 않았는지 확인)
  const digest = hash.digest("hex");
  if (manifest.sha256 && digest.toLowerCase() !== manifest.sha256.toLowerCase()) {
    throw new Error("다운로드 파일 검증 실패 (SHA-256 불일치)");
  }

  // 압축 해제 (배포본 = 개인정보가 없는 깨끗한 소스)
  if (fs.existsSync(UPDATE_NEW_DIR)) fs.rmSync(UPDATE_NEW_DIR, { recursive: true, force: true });
  fs.mkdirSync(UPDATE_NEW_DIR, { recursive: true });
  const esc = (p: string) => p.replace(/'/g, "''");
  await runPowerShell(`Expand-Archive -LiteralPath '${esc(zipPath)}' -DestinationPath '${esc(UPDATE_NEW_DIR)}' -Force`);

  assertSafeExtraction();
  if (!fs.existsSync(path.join(UPDATE_NEW_DIR, "package.json"))) {
    throw new Error("업데이트 압축 파일이 올바르지 않습니다.");
  }
  // 적용 대기 상태를 디스크에 기록 (서버 재시작 후에도 유지됨)
  fs.writeFileSync(
    UPDATE_STATE_FILE,
    JSON.stringify({
      phase: "downloaded",
      version: updateState.lastCheck.latestVersion,
      notes: updateState.lastCheck.notes,
      downloadedAt: new Date().toISOString(),
    }, null, 2),
    "utf8"
  );
  updateState.phase = "downloaded";
  updateState.progress = 100;
}

// 서버 시작 시 이전에 준비만 되고 적용되지 않은 업데이트가 있으면 상태 복원
function restoreUpdateState() {
  try {
    if (!fs.existsSync(UPDATE_STATE_FILE)) return;
    const state = JSON.parse(fs.readFileSync(UPDATE_STATE_FILE, "utf8"));
    if (state && state.phase === "downloaded" && fs.existsSync(path.join(UPDATE_NEW_DIR, "package.json"))) {
      updateState.phase = "downloaded";
      updateState.progress = 100;
      updateState.lastCheck = {
        hasUpdate: true,
        currentVersion: getCurrentVersion(),
        latestVersion: state.version || "",
        notes: state.notes || "",
        checkedAt: new Date().toISOString(),
      };
      console.log(`[update] 적용 대기 중인 v${state.version} 업데이트 파일을 복원했습니다.`);
    }
  } catch (err) {
    console.error("[update] 업데이트 상태 복원 실패:", err);
  }
}

// Update API
app.get("/api/update/status", (req, res) => {
  res.json({
    success: true,
    enabled: !!loadUpdateConfig().updateUrl,
    currentVersion: getCurrentVersion(),
    phase: updateState.phase,
    progress: updateState.progress,
    error: updateState.error,
    lastCheck: updateState.lastCheck,
  });
});

app.post("/api/update/check", async (req, res) => {
  try {
    updateState.phase = "checking";
    updateState.error = "";
    const manifest = await fetchUpdateManifest();
    const currentVersion = getCurrentVersion();
    if (!manifest) {
      updateState.phase = "idle";
      updateState.lastCheck = {
        hasUpdate: false,
        currentVersion,
        latestVersion: "",
        notes: "",
        checkedAt: new Date().toISOString(),
      };
      return res.json({ success: true, hasUpdate: false, currentVersion, message: "업데이트 서버에 등록된 버전이 아직 없습니다." });
    }
    const hasUpdate = compareVersions(manifest.version, currentVersion) > 0;
    updateState.lastCheck = {
      hasUpdate,
      currentVersion,
      latestVersion: manifest.version,
      notes: manifest.notes || "",
      checkedAt: new Date().toISOString(),
    };
    updateState.phase = hasUpdate ? "available" : "idle";
    res.json({ success: true, hasUpdate, currentVersion, latestVersion: manifest.version, notes: manifest.notes || "" });
  } catch (err: any) {
    updateState.phase = "error";
    updateState.error = err?.message || "업데이트 확인 중 오류가 발생했습니다.";
    res.json({ success: false, message: updateState.error });
  }
});

app.post("/api/update/download", async (req, res) => {
  if (!updateState.lastCheck.hasUpdate) {
    return res.status(400).json({ success: false, message: "업데이트할 버전이 없습니다. 먼저 업데이트 확인을 해주세요." });
  }
  if (updateState.phase === "downloading") {
    return res.json({ success: true, message: "이미 다운로드 중입니다." });
  }
  updateState.phase = "downloading";
  updateState.progress = 0;
  updateState.error = "";
  res.json({ success: true, message: "다운로드를 시작했습니다." });
  // 응답을 먼저 보내고 백그라운드로 다운로드 진행 (프론트는 status 폴링)
  downloadAndExtractUpdate().catch((err: any) => {
    updateState.phase = "error";
    updateState.error = err?.message || "다운로드 중 오류가 발생했습니다.";
  });
});

app.post("/api/update/apply", async (req, res) => {
  try {
    if (updateState.phase !== "downloaded") {
      return res.status(400).json({ success: false, message: "아직 업데이트 파일이 준비되지 않았습니다." });
    }
    // package.json 변경 여부 → 재시작 스크립트에서 npm install 실행 플래그
    const oldPkg = fs.existsSync(path.join(process.cwd(), "package.json"))
      ? fs.readFileSync(path.join(process.cwd(), "package.json"), "utf8")
      : "";
    const newPkg = fs.existsSync(path.join(UPDATE_NEW_DIR, "package.json"))
      ? fs.readFileSync(path.join(UPDATE_NEW_DIR, "package.json"), "utf8")
      : "";
    if (oldPkg !== newPkg) {
      fs.writeFileSync(path.join(UPDATE_TMP_DIR, "need-install.flag"), "1", "utf8");
    }

    const batPath = path.join(process.cwd(), "업데이트 재시작.bat");
    if (!fs.existsSync(batPath)) {
      return res.status(500).json({ success: false, message: "재시작 스크립트(업데이트 재시작.bat)를 찾을 수 없습니다." });
    }
    updateState.phase = "applying";
    // 3초 후 서버를 종료하고 파일 교체 → 새 버전 서버 재기동 (detached)
    const child = spawn("cmd.exe", ["/c", `"${batPath}"`], { detached: true, stdio: "ignore", windowsHide: false });
    child.unref();
    res.json({ success: true, message: "업데이트 적용 중... 잠시 후 프로그램이 자동으로 재시작됩니다." });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err?.message || "업데이트 적용 중 오류가 발생했습니다." });
  }
});

// Vite & Static Asset integration
async function startServer() {
  // 이전에 준비된(미적용) 업데이트 상태 복원
  restoreUpdateState();
  // Sync core database seeds
  await ensureLocalData();

  if (process.env.NODE_ENV !== "production") {
    // Development mode
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production mode
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Express custom server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
