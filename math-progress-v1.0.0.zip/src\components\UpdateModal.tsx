import { useState, useEffect, useRef } from 'react';
import { X, RefreshCw, Download, Rocket, CheckCircle2, AlertTriangle, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';

export interface UpdateStatus {
  success: boolean;
  enabled: boolean;
  currentVersion: string;
  phase: 'idle' | 'checking' | 'available' | 'downloading' | 'downloaded' | 'applying' | 'error';
  progress: number;
  error: string;
  lastCheck: {
    hasUpdate: boolean;
    currentVersion: string;
    latestVersion: string;
    notes: string;
    checkedAt: string;
  };
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export default function UpdateModal({ isOpen, onClose }: Props) {
  const [status, setStatus] = useState<UpdateStatus | null>(null);
  const pollRef = useRef<number | null>(null);

  const fetchStatus = async () => {
    try {
      const res = await fetch('/api/update/status');
      const data = await res.json();
      setStatus(data);
      return data as UpdateStatus;
    } catch {
      return null;
    }
  };

  const stopPolling = () => {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
  };

  // 다운로드 중 상태 폴링
  useEffect(() => {
    if (!isOpen) return;
    fetchStatus();
    return stopPolling;
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    if (status?.phase !== 'downloading') return;
    stopPolling();
    pollRef.current = window.setInterval(async () => {
      const data = await fetchStatus();
      if (!data) return;
      if (data.phase === 'downloaded' || data.phase === 'error' || data.phase === 'idle') {
        stopPolling();
      }
    }, 800);
    return stopPolling;
  }, [isOpen, status?.phase]);

  const handleCheck = async () => {
    setStatus(s => s ? { ...s, phase: 'checking' as const, error: '' } : s);
    try {
      const res = await fetch('/api/update/check', { method: 'POST' });
      const data = await res.json();
      await fetchStatus();
      if (!data.success) {
        setStatus(s => s ? { ...s, phase: 'error' as const, error: data.message || '업데이트 확인 실패' } : s);
      }
    } catch {
      setStatus(s => s ? { ...s, phase: 'error' as const, error: '서버 통신 중 오류가 발생했습니다.' } : s);
    }
  };

  const handleDownload = async () => {
    setStatus(s => s ? { ...s, phase: 'downloading' as const, progress: 0, error: '' } : s);
    try {
      await fetch('/api/update/download', { method: 'POST' });
      await fetchStatus();
    } catch {
      setStatus(s => s ? { ...s, phase: 'error' as const, error: '다운로드 요청 중 오류가 발생했습니다.' } : s);
    }
  };

  const handleApply = async () => {
    setStatus(s => s ? { ...s, phase: 'applying' as const, error: '' } : s);
    try {
      await fetch('/api/update/apply', { method: 'POST' });
    } catch {
      setStatus(s => s ? { ...s, phase: 'error' as const, error: '업데이트 적용 요청 중 오류가 발생했습니다.' } : s);
    }
  };

  const latest = status?.lastCheck?.latestVersion || '';
  const hasUpdate = status?.lastCheck?.hasUpdate || false;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-100 flex flex-col max-h-[85vh]"
      >
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-indigo-950 to-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/20 border border-indigo-500/30 rounded-xl">
              <Rocket className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">프로그램 업데이트</h3>
              <p className="text-[10px] text-indigo-300 mt-0.5 font-medium">
                현재 버전 v{status?.currentVersion || '—'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white rounded-xl transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {!status ? (
            <div className="flex items-center justify-center py-10 text-slate-400">
              <Loader2 className="w-5 h-5 animate-spin" />
              <span className="ml-2 text-xs font-bold">상태 확인 중...</span>
            </div>
          ) : !status.enabled ? (
            <div className="text-center py-8 space-y-3">
              <div className="w-14 h-14 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto">
                <Rocket className="w-6 h-6 text-slate-400" />
              </div>
              <p className="text-sm font-bold text-slate-700">자동 업데이트 기능이 비활성화되어 있습니다</p>
              <p className="text-xs text-slate-400 max-w-xs mx-auto leading-relaxed">
                update.config.json 파일에 업데이트 서버 주소가 설정되어 있지 않습니다.
                관리자에게 문의해주세요.
              </p>
            </div>
          ) : status.phase === 'applying' ? (
            <div className="text-center py-8 space-y-4">
              <div className="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto animate-pulse">
                <Rocket className="w-6 h-6 text-emerald-600" />
              </div>
              <div>
                <p className="text-sm font-black text-slate-800">업데이트 적용 중...</p>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  새 버전 파일을 적용하고 있습니다.<br />
                  잠시 후 프로그램이 <b className="text-emerald-600">자동으로 재시작</b>됩니다.<br />
                  창이 닫혀도 잠시 기다려 주세요!
                </p>
              </div>
              <div className="w-full max-w-xs mx-auto h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full animate-pulse" style={{ width: '70%' }} />
              </div>
            </div>
          ) : status.phase === 'error' ? (
            <div className="text-center py-8 space-y-4">
              <div className="w-14 h-14 bg-rose-100 rounded-2xl flex items-center justify-center mx-auto">
                <AlertTriangle className="w-6 h-6 text-rose-600" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-800">업데이트 확인에 실패했습니다</p>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">{status.error || '알 수 없는 오류'}</p>
                <p className="text-[10px] text-slate-400 mt-2">
                  인터넷 연결을 확인한 뒤 다시 시도해주세요. 오프라인 상태라면 계속 사용 가능합니다.
                </p>
              </div>
              <button
                onClick={handleCheck}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow transition-all active:scale-95 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                다시 시도
              </button>
            </div>
          ) : status.phase === 'checking' ? (
            <div className="flex items-center justify-center py-10 text-slate-400">
              <Loader2 className="w-5 h-5 animate-spin" />
              <span className="ml-2 text-xs font-bold">최신 버전을 확인 중...</span>
            </div>
          ) : status.phase === 'downloading' ? (
            <div className="space-y-5 py-6">
              <div className="text-center space-y-1.5">
                <p className="text-sm font-black text-slate-800">새 버전 v{latest} 다운로드 중...</p>
                <p className="text-xs text-slate-400">업데이트 파일을 안전하게 받아오고 있습니다.</p>
              </div>
              <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-indigo-600 to-violet-500 rounded-full transition-all duration-300"
                  style={{ width: `${status.progress}%` }}
                />
              </div>
              <p className="text-center text-[10px] font-mono text-slate-400">{status.progress}%</p>
            </div>
          ) : status.phase === 'downloaded' ? (
            <div className="text-center py-8 space-y-4">
              <div className="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-7 h-7 text-emerald-600" />
              </div>
              <div>
                <p className="text-sm font-black text-slate-800">다운로드 완료!</p>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  v{status.currentVersion} → <b className="text-indigo-600">v{latest}</b> 로 업데이트할 준비가 되었습니다.<br />
                  원생 데이터(data 폴더)는 그대로 보존됩니다.
                </p>
              </div>
              <button
                onClick={handleApply}
                className="inline-flex items-center gap-1.5 px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white rounded-2xl text-sm font-black shadow-lg shadow-emerald-500/25 transition-all active:scale-95 cursor-pointer"
              >
                <Rocket className="w-4 h-4" />
                지금 업데이트 적용
              </button>
            </div>
          ) : hasUpdate ? (
            <div className="space-y-4">
              {/* 버전 비교 카드 */}
              <div className="flex items-center justify-center gap-3 p-4 bg-indigo-50/60 rounded-2xl border border-indigo-100/70">
                <div className="text-center">
                  <div className="text-[10px] text-slate-400 font-bold mb-1">현재 버전</div>
                  <div className="text-sm font-black text-slate-500 line-through decoration-slate-300">
                    v{status.currentVersion}
                  </div>
                </div>
                <div className="flex items-center gap-1 text-indigo-400">
                  <span className="text-lg font-black">→</span>
                </div>
                <div className="text-center">
                  <div className="text-[10px] text-slate-400 font-bold mb-1">새 버전</div>
                  <div className="text-lg font-black text-indigo-600">v{latest}</div>
                </div>
              </div>

              {/* 릴리즈 노트 */}
              {status.lastCheck.notes && (
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                  <p className="text-[10px] font-bold text-slate-400 mb-1.5 uppercase tracking-wide">업데이트 내용</p>
                  <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-line">
                    {status.lastCheck.notes}
                  </p>
                </div>
              )}

              {/* 확인 시각 */}
              {status.lastCheck.checkedAt && (
                <p className="text-[10px] text-slate-400 text-center">
                  마지막 확인: {new Date(status.lastCheck.checkedAt).toLocaleString('ko-KR')}
                </p>
              )}

              <div className="pt-1">
                <button
                  onClick={handleDownload}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-indigo-600 to-violet-500 hover:from-indigo-500 hover:to-violet-400 text-white rounded-2xl text-sm font-black shadow-lg shadow-indigo-500/25 transition-all active:scale-95 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  업데이트 받기
                </button>
                <p className="text-[10px] text-slate-400 text-center mt-2 leading-relaxed">
                  🔒 다운로드 파일은 SHA-256 검증 후 적용됩니다. 원생 데이터는 안전하게 보존됩니다.
                </p>
              </div>
            </div>
          ) : (
            <div className="text-center py-8 space-y-3">
              <div className="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-7 h-7 text-emerald-600" />
              </div>
              <div>
                <p className="text-sm font-black text-slate-800">현재 최신 버전입니다!</p>
                <p className="text-xs text-slate-400 mt-1">v{status.currentVersion}</p>
              </div>
              {status.lastCheck.checkedAt && (
                <p className="text-[10px] text-slate-400">마지막 확인: {new Date(status.lastCheck.checkedAt).toLocaleString('ko-KR')}</p>
              )}
              <button
                onClick={handleCheck}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                다시 확인
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between shrink-0">
          <div className="text-[10px] text-slate-400 pl-1 font-medium leading-relaxed">
            * 업데이트 서버: GitHub<br />* data 폴더는 업데이트와 무관하게 보존됩니다.
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow transition-all active:scale-95 cursor-pointer"
          >
            닫기
          </button>
        </div>
      </motion.div>
    </div>
  );
}
