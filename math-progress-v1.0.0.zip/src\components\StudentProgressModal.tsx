import React, { useState, useEffect } from 'react';
import { Student, CurriculumBook, BookCategory, CategoryProgress, GradeType } from '../types';
import { X, Check, BookOpen, Layers, Award, Sparkles, HelpCircle } from 'lucide-react';

interface StudentProgressModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: Student;
  category: BookCategory;
  books: CurriculumBook[]; // 전체 교재 목록
  onSaveProgress: (studentId: string, category: BookCategory, updatedProgress: CategoryProgress) => Promise<void>;
}

export default function StudentProgressModal({
  isOpen,
  onClose,
  student,
  category,
  books,
  onSaveProgress
}: StudentProgressModalProps) {
  // 카테고리에 알맞은 전체 교재 필터링 (다른 학년 선택 가능하게)
  const categoryBooksAll = books.filter(b => b.category === category);

  // 해당 교재가 개별(임시 수동 기입)용인지 여부 검사
  const checkIfCustom = (id: string) => {
    if (!id || id === 'none') return false;
    // 만약 데이터베이스 등록 교재 리스트(books)에 존재하는 ID라면 절대 수동교재가 아님 (새로 추가된 교재 id=custom-book-* 대응)
    if (books.some(b => b.id === id)) return false;
    return id.startsWith('custom');
  };
  
  const gradesOrder: GradeType[] = ['1학년', '2학년', '3학년', '4학년', '5학년', '6학년'];
  const sortedGrades = [
    student.grade,
    ...gradesOrder.filter(g => g !== student.grade)
  ];

  // 해당 영역 기존 상태 로드
  const oldProgress = student.progress[category] || { bookId: 'none', completedUnits: {} };

  const [bookId, setBookId] = useState(oldProgress.bookId);
  const [customBookName, setCustomBookName] = useState(oldProgress.customBookName || '');
  const [completedUnits, setCompletedUnits] = useState<{ [key: string]: boolean }>(
    { ...oldProgress.completedUnits }
  );
  // 전체 학습 이력 (복수 교재 완료율 누적용)
  const [history, setHistory] = useState<{
    [bookId: string]: {
      bookId: string;
      customBookName?: string;
      completedUnits: { [unitName: string]: boolean };
      updatedAt?: string;
    };
  }>({ ...oldProgress.history });

  // '기타' 카테고리 등에서 사용자가 즉석에서 생성하는 개별 단원 리스트
  const [customUnitsInput, setCustomUnitsInput] = useState('');

  // 현재 선택된 실 교재 오브젝트
  const activeBook = books.find(b => b.id === bookId);

  // 컴포넌트 마운트/카테고리 변경 시 상태 복원
  useEffect(() => {
    const currentProg = student.progress[category] || { bookId: 'none', completedUnits: {} };
    let initialBookId = currentProg.bookId;
    let initialCustomBookName = currentProg.customBookName || '';
    let initialCompletedUnits = { ...currentProg.completedUnits };
    let initialHistory = currentProg.history || {};

    const isCustomBook = checkIfCustom(initialBookId) || !!initialCustomBookName;

    if (isCustomBook) {
      if (initialBookId === 'none' || initialBookId === 'custom') {
        initialBookId = `custom_${Date.now()}`;
      }
    }

    setBookId(initialBookId);
    setCustomBookName(initialCustomBookName);
    setCompletedUnits(initialCompletedUnits);
    setHistory(initialHistory);

    if (isCustomBook) {
      const unitNames = Object.keys(initialCompletedUnits);
      setCustomUnitsInput(unitNames.join('\n'));
    } else {
      setCustomUnitsInput('');
    }
  }, [student, category, isOpen]);

  // 기타 카테고리 기입 실시간 연동 편의성 지원
  const handleCustomNameChange = (val: string) => {
    setCustomBookName(val);
    if (!bookId || bookId === 'none' || !checkIfCustom(bookId)) {
      setBookId(`custom_${Date.now()}`);
    }
  };

  const handleCustomUnitsChange = (val: string) => {
    setCustomUnitsInput(val);
    if (!bookId || bookId === 'none' || !checkIfCustom(bookId)) {
      setBookId(`custom_${Date.now()}`);
    }
  };

  // 상황판 이력에서 교재를 완전히 삭제하고, 현재 활성 교재인 경우 초기화하는 함수
  const handleDeleteHistoryBook = (targetBookId: string) => {
    const updatedHistory = { ...history };
    delete updatedHistory[targetBookId];
    setHistory(updatedHistory);

    if (bookId === targetBookId) {
      setBookId('none');
      setCustomBookName('');
      setCompletedUnits({});
      setCustomUnitsInput('');
    }
  };

  // 교재 변경 시 단원 목록 및 히스토리 완충 스위칭 작업
  const handleBookChange = (newId: string) => {
    // 1. 현재 편집하고 있던 활성 교재의 임시 상태를 먼저 history 상태에 임시 백업해둡니다.
    if (bookId && bookId !== 'none') {
      const prevKey = bookId;
      setHistory(prev => ({
        ...prev,
        [prevKey]: {
          bookId: prevKey,
          customBookName: checkIfCustom(prevKey) ? customBookName : undefined,
          completedUnits: { ...completedUnits },
          updatedAt: new Date().toISOString()
        }
      }));
    }

    // 2. 새로운 교재 ID로 스위칭
    let finalId = newId;
    if (newId === 'custom_new') {
      finalId = `custom_${Date.now()}`;
    }
    setBookId(finalId);

    // 3. 만약 새로 전환하려는 교재의 과거 이력(예약 완료 단원 등)이 history에 저장되어 있다면 그대로 복제합니다.
    const isCustomBook = checkIfCustom(finalId);
    const pastRecord = (history || {})[finalId];
    if (pastRecord) {
      setCustomBookName(pastRecord.customBookName || '');
      setCompletedUnits({ ...pastRecord.completedUnits });
      if (isCustomBook && pastRecord.completedUnits) {
        setCustomUnitsInput(Object.keys(pastRecord.completedUnits).join('\n'));
      }
    } else {
      // 이력이 전무한 신생 선택이면 깨끗하게 초기화합니다.
      setCustomBookName('');
      setCompletedUnits({});
      if (isCustomBook) {
        setCustomUnitsInput('');
      } else {
        const targetDbBook = books.find(b => b.id === finalId);
        if (targetDbBook) {
          const freshMap: { [u: string]: boolean } = {};
          targetDbBook.units.forEach(u => {
            freshMap[u] = false;
          });
          setCompletedUnits(freshMap);
        }
      }
    }
  };

  if (!isOpen) return null;

  // 기타 카테고리 임시 로컬 챕터 적용기
  const applyCustomUnits = () => {
    const units = customUnitsInput
      .split('\n')
      .map(u => u.trim())
      .filter(u => u.length > 0);
    
    // 이전 완료 기록을 유지하면서 새로운 키값 매칭
    const newCompleted: { [key: string]: boolean } = {};
    units.forEach(u => {
      newCompleted[u] = completedUnits[u] || false;
    });
    setCompletedUnits(newCompleted);
  };

  // 단원 개별 마크 토글 (오프라인 완료 칸 칠하기!)
  const toggleUnit = (unitName: string) => {
    setCompletedUnits(prev => ({
      ...prev,
      [unitName]: !prev[unitName]
    }));
  };

  // 전체 선택 / 해제 단축 기능
  const setAllUnits = (status: boolean, unitsList: string[]) => {
    const fresh: { [key: string]: boolean } = {};
    unitsList.forEach(u => {
      fresh[u] = status;
    });
    setCompletedUnits(fresh);
  };

  // 저장 요청 제출
  const handleSave = async () => {
    const isCustomBook = checkIfCustom(bookId);
    let finalUnits = { ...completedUnits };

    if (isCustomBook) {
      const units = customUnitsInput
        .split('\n')
        .map(u => u.trim())
        .filter(u => u.length > 0);
      
      // 갱신
      finalUnits = {};
      units.forEach(u => {
        finalUnits[u] = completedUnits[u] || false;
      });
    }

    const currentKey = bookId;

    // 저장하는 시점에 마지막 상태를 히스토리 맵에 머지
    const updatedHistory = { ...history };
    if (currentKey !== 'none') {
      updatedHistory[currentKey] = {
        bookId: currentKey,
        customBookName: isCustomBook ? customBookName : undefined,
        completedUnits: finalUnits,
        updatedAt: new Date().toISOString()
      };
    }

    const updated: CategoryProgress = {
      bookId: currentKey,
      customBookName: isCustomBook && currentKey !== 'none' ? customBookName : undefined,
      completedUnits: currentKey === 'none' ? {} : finalUnits,
      history: updatedHistory
    };

    await onSaveProgress(student.id, category, updated);
         onClose();
  };

  // 현재 교재의 단원 리스트 확보
  const isCustomBook = checkIfCustom(bookId);
  const activeUnitsList = isCustomBook 
    ? customUnitsInput.split('\n').map(u => u.trim()).filter(u => u.length > 0)
    : (activeBook ? activeBook.units : []);

  // 진척도 환산
  const totalUnitsCount = activeUnitsList.length;
  const completedCount = activeUnitsList.filter(u => completedUnits[u]).length;
  const completionPercentage = totalUnitsCount > 0 
    ? Math.round((completedCount / totalUnitsCount) * 100) 
    : 0;

  // 카테고리별 테마 테일윈드 클래스 매핑
  const getCategoryTheme = (cat: string) => {
    const themes: { [key: string]: { bg: string, ring: string, text: string, cardBg: string } } = {
      '연산': { bg: 'bg-amber-500', ring: 'ring-amber-500/20', text: 'text-amber-700', cardBg: 'bg-amber-50/40' },
      '원리': { bg: 'bg-orange-500', ring: 'ring-orange-500/20', text: 'text-orange-700', cardBg: 'bg-orange-50/40' },
      '개념': { bg: 'bg-emerald-500', ring: 'ring-emerald-500/20', text: 'text-emerald-700', cardBg: 'bg-emerald-50/40' },
      '유형': { bg: 'bg-sky-500', ring: 'ring-sky-500/20', text: 'text-sky-700', cardBg: 'bg-sky-50/40' },
      '심화': { bg: 'bg-pink-500', ring: 'ring-pink-500/20', text: 'text-pink-700', cardBg: 'bg-pink-50/40' },
      '기타': { bg: 'bg-purple-500', ring: 'ring-purple-500/20', text: 'text-purple-700', cardBg: 'bg-purple-50/40' },
      '부교재': { bg: 'bg-rose-500', ring: 'ring-rose-500/20', text: 'text-rose-700', cardBg: 'bg-rose-50/40' }
    };
    return themes[cat] || { bg: 'bg-indigo-500', ring: 'ring-indigo-500/20', text: 'text-indigo-700', cardBg: 'bg-indigo-50/40' };
  };

  const theme = getCategoryTheme(category);

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className={`p-6 text-white bg-gradient-to-r ${
          category === '연산' ? 'from-amber-500 to-yellow-600' :
          category === '원리' ? 'from-orange-500 to-amber-600' :
          category === '개념' ? 'from-emerald-500 to-teal-600' :
          category === '유형' ? 'from-sky-500 to-indigo-600' :
          category === '심화' ? 'from-pink-500 to-rose-600' :
          category === '기타' ? 'from-purple-500 to-pink-600' :
          category === '부교재' ? 'from-rose-500 to-red-600' :
          'from-indigo-500 to-violet-600'
        } relative`}>
          <div className="absolute top-0 right-0 w-36 h-36 bg-white/5 rounded-full blur-2xl pointer-events-none" />
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/20 rounded-xl backdrop-blur-md">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-bold px-2 py-0.5 bg-white/20 rounded-full">
                    {student.school} {student.grade}
                  </span>
                  <span className="text-xs font-bold px-2 py-0.5 bg-white/30 rounded-full">
                    {category} 영역
                  </span>
                </div>
                <h3 className="text-xl font-bold mt-1">
                  <b>{student.name}</b> 학생의 진도 판정 보드
                </h3>
              </div>
            </div>
            
            <button 
              onClick={onClose}
              className="p-1.5 hover:bg-white/20 rounded-lg transition-all text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Form Content */}
        <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
          
          {/* 1. 진행 교재 선택기 */}
          <div className={`p-5 rounded-2xl border border-slate-100 ${theme.cardBg} space-y-3`}>
            <div className="flex items-center gap-1.5">
              <Layers className={`w-4 h-4 ${theme.text}`} />
              <h4 className="text-sm font-bold text-slate-800">진행 중인 교재 지정</h4>
            </div>

            <div>
              <select
                value={checkIfCustom(bookId) ? 'custom_new' : bookId}
                onChange={(e) => handleBookChange(e.target.value)}
                className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-xs font-semibold bg-white focus:outline-indigo-500 shadow-sm"
              >
                <option value="none">-- 교재 미등록 (수업 없음) --</option>
                {sortedGrades.map(grade => {
                  const gradeBooks = categoryBooksAll.filter(b => b.grade === grade);
                  if (gradeBooks.length === 0) return null;
                  
                  const isCurrentGrade = grade === student.grade;
                  
                  return (
                    <optgroup key={grade} label={`${isCurrentGrade ? '✨' : '📚'} ${grade}`}>
                      {gradeBooks.map(b => (
                        <option key={b.id} value={b.id}>
                          {b.category === '연산' ? b.name : `[${b.semester}] ${b.name}`}
                        </option>
                      ))}
                    </optgroup>
                  );
                })}
                
                <optgroup label="⚙️ 특별 기입 제어">
                  <option value="custom_new">➕ 직접 교재명 입력하여 추가 (수동 기입)</option>
                </optgroup>
              </select>
            </div>

            {isCustomBook && (
              <div className="space-y-4 pt-3 border-t border-slate-100/60 animate-in fade-in slide-in-from-top-1 duration-150">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <div className="text-xs font-bold text-slate-500 flex items-center gap-1.5">
                    <span>현재 편집 교재:</span>
                    <span className="font-semibold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-md">
                      {customBookName || '(새 교재 입력중)'}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      // 현재 편집 교재가 있었다면 먼저 임시 history에 백업
                      if (bookId && bookId !== 'none') {
                        const prevKey = bookId;
                        setHistory(prev => ({
                          ...prev,
                          [prevKey]: {
                            bookId: prevKey,
                            customBookName: checkIfCustom(prevKey) ? customBookName : undefined,
                            completedUnits: { ...completedUnits },
                            updatedAt: new Date().toISOString()
                          }
                        }));
                      }

                      // 백업 후, 깨끗하게 새 custom ID로 초기화
                      const newId = `custom_${Date.now()}`;
                      setBookId(newId);
                      setCustomBookName('');
                      setCompletedUnits({});
                      setCustomUnitsInput('');
                    }}
                    className="inline-flex items-center gap-1 px-2.5 py-1 bg-purple-100 hover:bg-purple-200 text-purple-700 hover:text-purple-800 rounded-lg text-[10px] font-bold transition-all cursor-pointer shadow-sm active:scale-95"
                  >
                    <span>+ 새 수동 교재 추가</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-500">교재명 자유 기입</label>
                    <input
                      type="text"
                      required
                      value={customBookName}
                      onChange={(e) => handleCustomNameChange(e.target.value)}
                      placeholder="예) 수능 기초 특강, 올림피아드"
                      className="w-full mt-1.5 px-3 py-2 border border-slate-200 rounded-xl text-xs font-semibold focus:outline-indigo-500 bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-slate-500">진도 단원수 입력 설명</label>
                    <p className="text-[10px] text-slate-400 mt-2">
                      아래 단원 목록 칸에 한 줄에 하나씩 직접 기입하면, 그 즉시 색칠할 수 있는 전용 진도 블록들이 하단에 생성됩니다!
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 2. 교재가 지정된 경우, 세부 단원 편집 */}
          {(bookId !== 'none' || isCustomBook) ? (
            <div className="space-y-4">
              
              {/* 수동 교재 전용 단원 수동 기입 */}
              {isCustomBook && (
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-500">
                      세부 단원/챕터 구성 목록 (한 줄에 한 개)
                    </label>
                    <button
                      type="button"
                      onClick={applyCustomUnits}
                      className="text-xs font-bold text-indigo-600 hover:text-indigo-800"
                    >
                      단원 블록 반영하기
                    </button>
                  </div>
                  <textarea
                    rows={3}
                    value={customUnitsInput}
                    onChange={(e) => handleCustomUnitsChange(e.target.value)}
                    placeholder="예)&#10;1주차: 분수 다지기&#10;2주차: 곱셈 정복&#10;3주차: 서술형 유형"
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-mono bg-white focus:outline-indigo-500"
                  />
                </div>
              )}

              {/* 완료 현황 미터구 */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <div className="flex items-center gap-1.5">
                  <Award className={`w-4- h-4 ${theme.text}`} />
                  <span className="text-xs font-bold text-slate-800">
                    오프라인 완료 체크판 (스티커 붙이기)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono text-slate-500 font-bold">
                    {completedCount}/{totalUnitsCount} 완료 ({completionPercentage}%)
                  </span>
                </div>
              </div>

              {/* 일괄 제어 및 간편 선택 조작기 */}
              {totalUnitsCount > 0 && (
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setAllUnits(true, activeUnitsList)}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-[10px] font-bold rounded-lg text-slate-600 transition-all cursor-pointer"
                  >
                    전체 단원 완료
                  </button>
                  <button
                    type="button"
                    onClick={() => setAllUnits(false, activeUnitsList)}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-rose-55 hover:text-rose-600 text-[10px] font-bold rounded-lg text-slate-600 transition-all cursor-pointer"
                  >
                    완료 전체 지우기
                  </button>
                </div>
              )}

              {/* 스틸 단원 시각 그리드 (벽에 붙이는 스키마 완벽 복각) */}
              {totalUnitsCount === 0 ? (
                <div className="text-center py-8 bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-slate-400 text-xs">
                  진행할 단원 구성이 비어있습니다.
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {activeUnitsList.map((unit, idx) => {
                    const isDone = completedUnits[unit] || false;
                    return (
                      <button
                        type="button"
                        key={idx}
                        onClick={() => toggleUnit(unit)}
                        className={`p-3 rounded-xl border text-left transition-all relative overflow-hidden group active:scale-95 cursor-pointer flex flex-col justify-between h-[72px] ${
                          isDone 
                            ? `${theme.bg} border-transparent text-white shadow-sm shadow-indigo-500/10` 
                            : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
                        }`}
                      >
                        <span className={`text-[10px] font-bold font-mono tracking-wider uppercase ${isDone ? 'text-white/80' : 'text-slate-400'}`}>
                          UNIT {idx + 1}
                        </span>
                        <span className="text-xs font-semibold leading-tight line-clamp-2 mt-1 pr-1.5">
                          {unit}
                        </span>

                        {isDone && (
                          <div className="absolute top-1.5 right-1.5 bg-white/20 p-0.5 rounded-full">
                            <Check className="w-3 h-3 text-white" />
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-12 text-slate-400 text-sm">
              <HelpCircle className="w-8 h-8 mx-auto text-slate-300 mb-2" />
              상위 지정 영역에서 현재 수업 중인 교재를 지정하시면<br />
              이곳에 해당 교재의 매칭 단원 완료 여부 체크판이 활성화됩니다.
            </div>
          )}

          {/* 3. 누적 학습 완료 교재 상황판 (기완료 교재 리스트 및 이전 복구판) */}
          {(() => {
            const historyList = Object.values(history || {}) as Array<{
              bookId: string;
              customBookName?: string;
              completedUnits: { [unitName: string]: boolean };
              updatedAt?: string;
            }>;
            const validHistory = historyList.filter(record => record.bookId !== 'none');

            if (validHistory.length === 0) return null;

            return (
              <div className="space-y-3 pt-5 border-t border-slate-100">
                <div className="flex items-center gap-1.5">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <h4 className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                    📚 이 영역 누적 학습 완료 교재 상황판
                    <span className="text-[10px] bg-slate-100 text-slate-500 font-bold px-2 py-0.5 rounded-full">
                      {validHistory.length}권 이력 보존됨
                    </span>
                  </h4>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {validHistory.map(record => {
                    let nameOfBook = '';
                    let totalOfBook = 0;
                    
                    if (checkIfCustom(record.bookId)) {
                      nameOfBook = record.customBookName || '기타 개별 교재';
                      totalOfBook = Object.keys(record.completedUnits || {}).length;
                    } else {
                      const matchedBook = books.find(b => b.id === record.bookId);
                      nameOfBook = matchedBook ? matchedBook.name : record.bookId;
                      totalOfBook = matchedBook ? matchedBook.units.length : 0;
                    }

                    const matchedCompletedMap = record.completedUnits || {};
                    const compCount = Object.values(matchedCompletedMap).filter(val => val === true).length;
                    const ratio = totalOfBook > 0 ? Math.round((compCount / totalOfBook) * 100) : 0;
                    const finished = totalOfBook > 0 && compCount === totalOfBook;

                    const isActive = bookId === record.bookId;

                    return (
                      <div 
                        key={record.bookId}
                        className={`p-3 rounded-2xl border transition-all relative group flex flex-col justify-between gap-2 ${
                          isActive 
                            ? 'bg-indigo-50/60 border-indigo-200 ring-2 ring-indigo-500/10 shadow-sm' 
                            : 'bg-slate-50/40 border-slate-200/60 hover:border-slate-300'
                        }`}
                      >
                        {/* 클릭 가능한 메인 영역 */}
                        <div 
                          onClick={() => handleBookChange(record.bookId)}
                          className="cursor-pointer space-y-2 flex-1"
                          title="클릭하여 이 교재의 세부 진도 체크판을 즉각 활성 소환합니다"
                        >
                          <div className="flex items-center justify-between w-full pr-5">
                            <span className="text-xs font-bold text-slate-800 truncate max-w-[130px]" title={nameOfBook}>
                              {nameOfBook} {isActive && <span className="text-[10px] bg-indigo-100 text-indigo-700 font-bold px-1.5 py-0.5 rounded ml-1">진행중</span>}
                            </span>
                            
                            {finished ? (
                              <span className="text-[9px] bg-emerald-100 text-emerald-800 font-extrabold px-1.5 py-0.5 rounded-md border border-emerald-200 shrink-0 font-sans">🏆 완강</span>
                            ) : (
                              <span className="text-[9px] text-slate-500 font-mono font-bold bg-white/80 px-1 py-0.5 border rounded shrink-0">
                                {compCount}/{totalOfBook}
                              </span>
                            )}
                          </div>

                          {/* 미니 완강 Progress Gauge */}
                          <div className="w-full bg-slate-200/70 rounded-full h-1.5 overflow-hidden">
                            <div 
                              className={`h-full transition-all ${finished ? 'bg-emerald-500' : 'bg-indigo-600'}`} 
                              style={{ width: `${ratio}%` }}
                            />
                          </div>

                          <div className="flex items-center justify-between text-[10px] text-slate-405 font-medium w-full">
                            <span className="text-slate-400">완료율 {ratio}%</span>
                            <span className="opacity-0 group-hover:opacity-100 text-indigo-600 font-bold transition-all text-right">클릭 시 소환 ⚡</span>
                          </div>
                        </div>

                        {/* 전체 삭제 버튼 (절대 좌표 배치) */}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteHistoryBook(record.bookId);
                          }}
                          className="absolute top-2.5 right-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 p-1 rounded-md transition-all shrink-0 cursor-pointer"
                          title="상황판 이력에서 교재 삭제"
                        >
                          <X className="w-3.5 h-3.5 stroke-[2.5]" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })()}

          {/* AI 추천 통찰 데모 */}
          {bookId !== 'none' && totalUnitsCount > 0 && (
            <div className="p-3 bg-indigo-50/50 rounded-xl border border-indigo-100/50 text-indigo-800 text-[11px] flex gap-2">
              <Sparkles className="w-4 h-4 shrink-0 text-indigo-500 mt-0.5" />
              <div>
                <b>인공지능 진학 보정 팩:</b> 현재 <b>{student.name}</b> 원생의 {category} 진도는 양호한 흐름입니다. 학습 효율을 극대화하기 위해 다음 단원 진행 전에 계산 보강 문제 또는 디딤돌 부교재 {idxOffsetCalc(idxLastUnit(activeUnitsList, completedUnits))}단원을 풀도록 사전에 안배하는 것을 권장합니다.
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 bg-slate-50 border-t border-slate-100 flex justify-end gap-2.5">
          <button 
            type="button" 
            onClick={onClose}
            className="px-4 py-2 border border-slate-200 hover:bg-slate-100 text-slate-600 font-bold rounded-xl text-xs transition-all"
          >
            취소
          </button>
          <button 
            type="button" 
            onClick={handleSave}
            className="inline-flex items-center gap-1.5 px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs transition-all shadow-md cursor-pointer active:scale-95"
          >
            <Check className="w-4 h-4" />
            진도 저장 완료
          </button>
        </div>
      </div>
    </div>
  );
}

// 헬퍼 기능들
function idxLastUnit(units: string[], competed: { [key: string]: boolean }): number {
  let idx = 0;
  units.forEach((u, i) => {
    if (competed[u]) idx = i;
  });
  return idx;
}

function idxOffsetCalc(lastIdx: number): number {
  return (lastIdx % 6) + 1;
}
