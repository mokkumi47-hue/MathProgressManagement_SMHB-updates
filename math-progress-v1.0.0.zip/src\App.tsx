import { useState, useEffect } from 'react';
import { Student, CurriculumBook, BookCategory, CategoryProgress } from './types';
import StudentTable from './components/StudentTable';
import StudentProgressModal from './components/StudentProgressModal';
import StudentFormModal from './components/StudentFormModal';
import CurriculumModal from './components/CurriculumModal';
import UpdateModal from './components/UpdateModal';
import { Calendar, GraduationCap, Layers, CheckCircle2, Database, User, ShoppingBag, Check, Copy, X, Rocket, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [students, setStudents] = useState<Student[]>([]);
  const [books, setBooks] = useState<CurriculumBook[]>([]);
  const [categories, setCategories] = useState<BookCategory[]>([]);
  const [loading, setLoading] = useState(true);

  // 모달 제어 상태
  const [isProgressOpen, setIsProgressOpen] = useState(false);
  const [activeStudentForProgress, setActiveStudentForProgress] = useState<Student | null>(null);
  const [activeCategoryForProgress, setActiveCategoryForProgress] = useState<BookCategory | null>(null);

  const [isStudentFormOpen, setIsStudentFormOpen] = useState(false);
  const [activeStudentForForm, setActiveStudentForForm] = useState<Student | null>(null);

  const [isCurriculumOpen, setIsCurriculumOpen] = useState(false);
  const [isOrderOpen, setIsOrderOpen] = useState(false);
  const [selectedOrderPIds, setSelectedOrderPIds] = useState<string[]>([]);

  // 자동 업데이트 상태
  const [isUpdateOpen, setIsUpdateOpen] = useState(false);
  const [updateInfo, setUpdateInfo] = useState<{
    hasUpdate: boolean;
    latestVersion: string;
    currentVersion: string;
  } | null>(null);

  // 1. API 데이터 취득
  const fetchData = async () => {
    try {
      setLoading(true);
      const [resStudents, resCurriculum, resCategories] = await Promise.all([
        fetch('/api/students'),
        fetch('/api/curriculum'),
        fetch('/api/categories')
      ]);

      const dataStudents = await resStudents.json();
      const dataCurriculum = await resCurriculum.json();
      const dataCategories = await resCategories.json();

      if (dataStudents.success) setStudents(dataStudents.data);
      if (dataCurriculum.success) setBooks(dataCurriculum.data);
      if (dataCategories.success) setCategories(dataCategories.data || ["연산", "원리", "개념", "유형", "심화", "기타", "부교재"]);
    } catch (err) {
      console.error("데이터 통신 지연 오류: ", err);
    } finally {
      setLoading(false);
    }
  };

  // 대분류 저장 및 동기화 처리
  const handleSaveCategories = async (
    newCategories: BookCategory[],
    renameMap?: { [oldName: string]: string },
    deleteList?: string[]
  ) => {
    try {
      const response = await fetch('/api/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ categories: newCategories, renameMap, deleteList })
      });
      const result = await response.json();
      if (result.success) {
        setCategories(result.categories);
        if (result.curriculum) setBooks(result.curriculum);
        if (result.students) setStudents(result.students);
      }
    } catch (err) {
      alert("대분류 교재 카테고리 구성 저장 중 오류가 발생했습니다.");
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // 시작 시 자동 업데이트 확인 (수동 버튼은 헤더에 별도 배치)
  useEffect(() => {
    const t = window.setTimeout(() => {
      fetch('/api/update/check', { method: 'POST' })
        .then(res => res.json())
        .then(data => {
          if (data && typeof data.hasUpdate === 'boolean') {
            setUpdateInfo({
              hasUpdate: data.hasUpdate,
              latestVersion: data.latestVersion || '',
              currentVersion: data.currentVersion || '',
            });
          }
        })
        .catch(() => {
          /* 오프라인이거나 서버 미구성 시 조용히 무시 */
        });
    }, 1500);
    return () => window.clearTimeout(t);
  }, []);

  // 2. 학생 추가 및 수정 처리
  const handleSaveStudent = async (student: Student): Promise<boolean> => {
    try {
      const isEdit = students.some(s => s.id === student.id);
      const url = isEdit ? `/api/students/${student.id}` : '/api/students';
      const method = isEdit ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(student)
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        alert(`원생 정보를 저장하지 못했습니다 (${response.status}): ${errData.message || "서버 응답 오류"}`);
        return false;
      }

      const result = await response.json();
      if (result.success) {
        setStudents(result.data);
        return true;
      } else {
        alert(`원생 저장 실패: ${result.message || "알 수 없는 오류"}`);
        return false;
      }
    } catch (err: any) {
      alert("서버와 통신하는 중 장해가 발생했습니다: " + (err.message || err));
      return false;
    }
  };

  // 3. 학생 삭제 처리
  const handleDeleteStudent = async (id: string) => {
    try {
      const response = await fetch(`/api/students/${id}`, { method: 'DELETE' });
      const result = await response.json();
      if (result.success) {
        setStudents(result.data);
      }
    } catch (err) {
      alert("학생 삭제 중 오류가 발생했습니다.");
    }
  };

  // 4. 교재(Curriculum) 추가 및 수정 처리
  const handleSaveBook = async (book: CurriculumBook) => {
    try {
      const isEdit = books.some(b => b.id === book.id);
      const url = isEdit ? `/api/curriculum/${book.id}` : '/api/curriculum';
      const method = isEdit ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(book)
      });
      const result = await response.json();
      if (result.success) {
        setBooks(result.data);
        // 교재 수정 후 혹시 학생 칩 리랜더링을 위해 학생 정보도 한번 받아옵니다.
        const resStudents = await fetch('/api/students');
        const dataStudents = await resStudents.json();
        if (dataStudents.success) setStudents(dataStudents.data);
      }
    } catch (err) {
      alert("교재 보존 처리 오류.");
    }
  };

  // 5. 교재 삭제 처리
  const handleDeleteBook = async (id: string) => {
    try {
      const response = await fetch(`/api/curriculum/${id}`, { method: 'DELETE' });
      const result = await response.json();
      if (result.success) {
        setBooks(result.data || []);
        alert("교재가 성공적으로 삭제되었습니다.");
      } else {
        alert(result.message || "교재 삭제에 실패했습니다.");
      }
    } catch (err) {
      console.error(err);
      alert("교재 삭제 중 네트워크 오류가 발생했습니다.");
    }
  };

  // 6. 개별 진도 및 완료 여부(색칠 칸) 저장
  const handleSaveCategoryProgress = async (
    studentId: string,
    category: BookCategory,
    updatedProgress: CategoryProgress
  ) => {
    try {
      const targetStudent = students.find(s => s.id === studentId);
      if (!targetStudent) return;

      // 만약 학습예정 리스트(plannedBookIds)에 등록된 교재를 진행 카테고리로 올리면 자동삭제 처리!
      const newBookId = updatedProgress.bookId;
      let nextPlanned = targetStudent.plannedBookIds || [];
      if (newBookId && newBookId !== 'none') {
        nextPlanned = nextPlanned.filter(id => id !== newBookId && !id.startsWith(`${newBookId}::`));
      }

      const updatedStudent: Student = {
        ...targetStudent,
        progress: {
          ...targetStudent.progress,
          [category]: updatedProgress
        },
        plannedBookIds: nextPlanned
      };

      await handleSaveStudent(updatedStudent);
    } catch (err) {
      console.error(err);
    }
  };

  // 7. 교재 주문 완료 일괄 제거 기능
  const handleCompleteOrders = async (pIdsToComplete: string[]) => {
    if (!pIdsToComplete || pIdsToComplete.length === 0) return;
    
    if (!window.confirm(`선택한 ${pIdsToComplete.length}종의 교재를 주문 완료하시겠습니까?\n완료 시, 학생들의 [학습예정 교재리스트]에서 자동 삭제되며 이 집계표에서도 제외됩니다.`)) {
      return;
    }
    
    try {
      const response = await fetch('/api/students/complete-orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pIds: pIdsToComplete })
      });
      const result = await response.json();
      if (result.success) {
        setStudents(result.data);
        setSelectedOrderPIds([]);
        alert("🎉 주문 완료 처리가 완료되었습니다! 해당 교재들이 학생들의 예정 리스트 및 집계 표에서 성공적으로 삭제 처리되었습니다.");
      } else {
        alert("주문 완료 연동 실패: " + (result.message || "서버 응답 오류"));
      }
    } catch (err: any) {
      alert("서버와 통신하는 도중 오류가 발생하였습니다: " + err.message);
    }
  };

  // 모달 오픈 트리거
  const openProgressModal = (student: Student, category: BookCategory) => {
    setActiveStudentForProgress(student);
    setActiveCategoryForProgress(category);
    setIsProgressOpen(true);
  };

  const openStudentFormModal = (student: Student | null) => {
    setActiveStudentForForm(student);
    setIsStudentFormOpen(true);
  };

  // 심플 통계 데이터 계산
  const totalStudents = students.length;
  const activeBookings = students.flatMap(s => 
    (Object.values(s.progress) as CategoryProgress[]).filter(p => p.bookId !== 'none' && p.bookId !== '')
  ).length;

  const totalFinishedBookUnits = students.flatMap(s => 
    (Object.values(s.progress) as CategoryProgress[]).flatMap(p => 
      Object.values(p.completedUnits).filter(val => val === true)
    )
  ).length;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between selection:bg-indigo-100 selection:text-indigo-900">
      
      {/* GLOBAL BACKGROUND ELEMENTS */}
      <div className="absolute top-0 left-0 right-0 h-64 bg-slate-900 text-white z-0 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-tr from-indigo-950 via-slate-900 to-slate-950 opacity-90" />
        <div className="absolute top-[-100px] right-[-100px] w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl" />
        <div className="absolute top-[50px] left-[-150px] w-80 h-80 bg-emerald-500/5 rounded-full blur-2xl" />
      </div>

      {/* CORE CONTAINER */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 flex-1">
        
        {/* Navigation Bar */}
        <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/10 border border-indigo-500/20 rounded-2xl backdrop-blur-md">
              <GraduationCap className="w-6 h-6 text-indigo-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-1.5">
                초등 수학 진도 관리 센터
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-extrabold px-2 py-0.5 rounded-full uppercase border border-emerald-500/30">
                  로컬 저장
                </span>
              </h1>
              <p className="text-xs text-slate-400 font-medium">
                초등부 영역별 교재 진도 상태를 한눈에 모니터링하고 즉석 마킹하는 통합 대시보드
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 self-start sm:self-auto shrink-0 select-none">
            <button
              onClick={() => { setSelectedOrderPIds([]); setIsOrderOpen(true); }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-600 to-emerald-500 hover:from-teal-500 hover:to-emerald-400 text-white rounded-2xl text-xs font-black shadow-lg shadow-teal-950/20 transition-all active:scale-95 cursor-pointer ring-1 ring-teal-400 border border-teal-500/25"
            >
              <ShoppingBag className="w-4 h-4 text-white" />
              <span>교재 주문 집계</span>
              <span className="bg-teal-900/40 text-teal-100 text-[10px] px-1.5 py-0.5 rounded-full font-black min-w-[1.5rem] text-center">
                {students.reduce((acc, s) => acc + (s.plannedBookIds || []).length, 0)}권
              </span>
            </button>

            <button
              onClick={() => setIsUpdateOpen(true)}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-black transition-all active:scale-95 cursor-pointer border backdrop-blur-sm ${
                updateInfo?.hasUpdate
                  ? 'bg-amber-500/15 border-amber-400/40 text-amber-200 hover:bg-amber-500/25 shadow-lg shadow-amber-950/20'
                  : 'bg-slate-800/40 border-white/10 text-slate-300 hover:bg-slate-700/50'
              }`}
            >
              {updateInfo?.hasUpdate ? <Rocket className="w-4 h-4 text-amber-300" /> : <RefreshCw className="w-4 h-4 text-indigo-300" />}
              <span>업데이트</span>
              {updateInfo?.hasUpdate ? (
                <span className="bg-amber-500 text-slate-900 text-[10px] px-1.5 py-0.5 rounded-full font-black min-w-[1.5rem] text-center animate-pulse">
                  v{updateInfo.latestVersion}
                </span>
              ) : updateInfo ? (
                <span className="text-[10px] text-slate-500 font-bold">v{updateInfo.currentVersion}</span>
              ) : null}
            </button>

            <div className="flex items-center gap-2 bg-slate-800/40 border border-white/10 px-4 py-2 rounded-2xl backdrop-blur-sm">
              <Calendar className="w-4 h-4 text-indigo-300" />
              <span className="text-xs font-mono font-bold text-slate-300">
                {new Date().toLocaleDateString('ko-KR', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'short' })}
              </span>
            </div>
          </div>
        </header>

        {/* 새 버전 알림 배너 */}
        <AnimatePresence>
          {updateInfo?.hasUpdate && !isUpdateOpen && (
            <motion.div
              initial={{ opacity: 0, y: -12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              className="relative z-10 flex flex-col sm:flex-row sm:items-center gap-3 px-5 py-4 bg-gradient-to-r from-amber-500/15 to-orange-500/10 border border-amber-400/30 rounded-2xl backdrop-blur-md shadow-lg shadow-amber-950/10"
            >
              <div className="flex items-center gap-3 flex-1">
                <div className="p-2 bg-amber-500/20 rounded-xl shrink-0">
                  <Rocket className="w-5 h-5 text-amber-300" />
                </div>
                <div>
                  <p className="text-xs font-black text-amber-100">
                    새 버전 v{updateInfo.latestVersion} 사용 가능!
                  </p>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    원생 데이터는 그대로 보존되며, 한 번의 클릭으로 업데이트할 수 있습니다.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsUpdateOpen(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-900 rounded-xl text-xs font-black shadow-lg shadow-amber-950/20 transition-all active:scale-95 cursor-pointer shrink-0"
              >
                <Rocket className="w-3.5 h-3.5" />
                지금 업데이트
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* TOP METRICS BENTO CARDS */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          <div className="p-5 bg-white/10 border border-white/10 text-white rounded-2xl flex items-center gap-4 shadow-lg backdrop-blur-md">
            <div className="p-3 rounded-xl bg-indigo-500/20 text-indigo-300">
              <User className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs text-slate-400 font-medium">재원 초등학생 수</span>
              <h4 className="text-2xl font-black font-mono mt-0.5">{totalStudents}명</h4>
            </div>
          </div>

          <div className="p-5 bg-white/10 border border-white/10 text-white rounded-2xl flex items-center gap-4 shadow-lg backdrop-blur-md">
            <div className="p-3 rounded-xl bg-orange-500/20 text-orange-300">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs text-slate-400 font-medium">진행 중인 교재 수</span>
              <h4 className="text-2xl font-black font-mono mt-0.5">{activeBookings}개</h4>
            </div>
          </div>

          <div className="p-5 bg-white/10 border border-white/10 text-white rounded-2xl flex items-center gap-4 shadow-lg backdrop-blur-md">
            <div className="p-3 rounded-xl bg-emerald-500/20 text-emerald-300">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs text-slate-400 font-medium">누적 완료 단원수</span>
              <h4 className="text-2xl font-black font-mono mt-0.5">{totalFinishedBookUnits}개</h4>
            </div>
          </div>

          <div className="p-5 bg-white/10 border border-white/10 text-white rounded-2xl flex items-center gap-4 shadow-lg backdrop-blur-md">
            <div className="p-3 rounded-xl bg-purple-500/20 text-purple-300">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs text-slate-400 font-medium">로컬 파일 저장</span>
              <h4 className="text-sm font-bold text-slate-300 mt-1 uppercase">내 컴퓨터 영구보존</h4>
            </div>
          </div>

        </div>

        {/* LOADING PROGRESS BAR */}
        {loading ? (
          <div className="py-24 text-center bg-white rounded-3xl border border-slate-100 shadow-md">
            <div className="inline-block relative w-12 h-12">
              <div className="absolute inset-0 border-4 border-indigo-100 rounded-full" />
              <div className="absolute inset-0 border-4 border-t-indigo-600 rounded-full animate-spin" />
            </div>
            <p className="text-xs text-slate-500 font-bold mt-4 tracking-wider uppercase animate-pulse">
              통합 진도 데이터를 로드 중입니다...
            </p>
          </div>
        ) : (
          /* MAIN TABLE SECTION */
          <StudentTable
            students={students}
            books={books}
            categories={categories}
            onOpenProgress={openProgressModal}
            onOpenStudentForm={openStudentFormModal}
            onOpenCurriculum={() => setIsCurriculumOpen(true)}
            onSaveStudent={handleSaveStudent}
          />
        )}

      </div>

      {/* FOOTER */}
      <footer className="py-8 bg-slate-900 border-t border-slate-800 text-center relative z-10 mt-12 text-slate-500 text-xs">
        <p className="font-mono">© 초등 수학 진도 관리 센터</p>
        <p className="text-slate-600 mt-1">
          모든 데이터는 이 컴퓨터의 data 폴더(JSON 파일)에 안전하게 저장됩니다.
        </p>
      </footer>

      {/* 1. STUDENT PROGRESS COLOR MARK SHEET MODAL */}
      {isProgressOpen && activeStudentForProgress && activeCategoryForProgress && (
        <StudentProgressModal
          isOpen={isProgressOpen}
          onClose={() => {
            setIsProgressOpen(false);
            setActiveStudentForProgress(null);
            setActiveCategoryForProgress(null);
          }}
          student={activeStudentForProgress}
          category={activeCategoryForProgress}
          books={books}
          onSaveProgress={handleSaveCategoryProgress}
        />
      )}

      {/* 2. STUDENT SIMPLE FORM MODAL */}
      {isStudentFormOpen && (
        <StudentFormModal
          isOpen={isStudentFormOpen}
          onClose={() => {
            setIsStudentFormOpen(false);
            setActiveStudentForForm(null);
          }}
          student={activeStudentForForm}
          categories={categories}
          onSave={handleSaveStudent}
          onDelete={handleDeleteStudent}
        />
      )}

      {/* 3. CURRICULUM CONFIGURATION MODAL */}
      {isCurriculumOpen && (
        <CurriculumModal
          isOpen={isCurriculumOpen}
          onClose={() => {
            setIsCurriculumOpen(false);
          }}
          books={books}
          categories={categories}
          onSaveBook={handleSaveBook}
          onDeleteBook={handleDeleteBook}
          onSaveCategories={handleSaveCategories}
        />
      )}

      {/* 5. AUTO UPDATE MODAL */}
      {isUpdateOpen && (
        <UpdateModal
          isOpen={isUpdateOpen}
          onClose={() => setIsUpdateOpen(false)}
        />
      )}

      {/* 4. TOTAL BOOK ORDERS AGGREGATION MODAL */}
      <AnimatePresence>
        {isOrderOpen && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden border border-slate-100 flex flex-col max-h-[85vh]"
            >
              {/* Header */}
              <div className="p-6 bg-gradient-to-r from-teal-950 to-slate-900 text-white flex items-center justify-between shrink-0">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-teal-500/20 border border-teal-500/30 rounded-xl">
                    <ShoppingBag className="w-5 h-5 text-teal-400" />
                  </div>
                  <div>
                    <h3 className="font-bold text-base text-white">
                      교재 통합 주문수량 분석기
                    </h3>
                    <p className="text-[10px] text-teal-300 mt-0.5 font-medium">
                      학생들이 학습예정 리스트로 등록한 교재 수요를 집계하여 주문 서류 작성을 돕습니다.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setIsOrderOpen(false)}
                  className="p-1.5 bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white rounded-xl transition-all cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Body */}
              <div className="p-6 overflow-y-auto space-y-5 flex-1">
                {(() => {
                  // 집계 분석 가동 (개별 볼륨 및 일반 단일 교재 모두 분리 취합)
                  const agg: { 
                    [pId: string]: { 
                      book: CurriculumBook; 
                      unitName?: string; 
                      displayName: string;
                      cnt: number; 
                      studentNames: string[] 
                    } 
                  } = {};

                  students.forEach(s => {
                    const planned = s.plannedBookIds || [];
                    planned.forEach(pId => {
                      const [bId, unitName] = pId.split("::");
                      const b = books.find(book => book.id === bId);
                      if (b) {
                        const displayName = b.category === '연산'
                          ? (unitName || b.name)
                          : (unitName ? `[${b.semester}] ${unitName}` : `[${b.semester}] ${b.name}`);
                        if (!agg[pId]) {
                          agg[pId] = { 
                            book: b, 
                            unitName, 
                            displayName,
                            cnt: 0, 
                            studentNames: [] 
                          };
                        }
                        agg[pId].cnt += 1;
                        if (!agg[pId].studentNames.includes(s.name)) {
                          agg[pId].studentNames.push(s.name);
                        }
                      }
                    });
                  });

                  const orderData = Object.entries(agg).map(([pId, val]) => ({
                    pId,
                    ...val
                  })).sort((a, b) => {
                    const gradeCompare = a.book.grade.localeCompare(b.book.grade);
                    if (gradeCompare !== 0) return gradeCompare;
                    return a.displayName.localeCompare(b.displayName);
                  });

                  const totalCount = orderData.reduce((acc, o) => acc + o.cnt, 0);

                  const handleCopyToClipboard = () => {
                    if (orderData.length === 0) return;
                    const text = `[초등 수학 학원 교재 주문 집계서]\n출력시기: ${new Date().toLocaleDateString('ko-KR')}\n\n` +
                      orderData.map((o, idx) => `${idx + 1}. [${o.book.grade}] ${o.displayName} (${o.book.category}) - ${o.cnt}권\n   (학습예정: ${o.studentNames.join(", ")})`).join("\n\n") +
                      `\n\n-------------------------------\n총 ${totalCount}권 주문이 필요합니다.`;

                    navigator.clipboard.writeText(text).then(() => {
                      alert("📋 교재 주문 사양이 클립보드에 복사되었습니다! 메모장이나 네이버 밴드 등에 붙여넣어 요긴하게 활용하세요.");
                    });
                  };

                  if (orderData.length === 0) {
                    return (
                      <div className="text-center py-16 text-slate-450 space-y-3">
                        <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-350">
                          <ShoppingBag className="w-8 h-8" />
                        </div>
                        <div className="text-sm font-bold text-slate-700">대기 중인 교재 주문 분석 결과가 없습니다.</div>
                        <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
                          반 학생들의 <b>[미학습교재]</b> 버튼을 각각 누르신 뒤, 학습 로드맵상 다음 학습 예정이 될 책들을 클릭하여 찜해주시면 자동으로 이곳에 취합 집계됩니다!
                        </p>
                      </div>
                    );
                  }

                  return (
                    <div className="space-y-4">
                      
                      {/* 설명 & 퀵 통계 툴바 */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-teal-50/50 p-4 rounded-2xl border border-teal-100/60 font-semibold text-xs text-teal-950">
                        <div className="leading-relaxed">
                          현재까지 총 <span className="text-teal-700 font-extrabold">{orderData.length}가지 종류</span>의 교재에서 <span className="text-teal-700 font-extrabold">{totalCount}권</span>의 개별 교재 수요가 발생했습니다.
                        </div>
                        <button
                          type="button"
                          onClick={handleCopyToClipboard}
                          className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 bg-white border border-teal-200 text-teal-800 hover:bg-teal-100/40 rounded-xl font-bold cursor-pointer transition-all active:scale-95 shrink-0"
                        >
                          <Copy className="w-3.5 h-3.5" />
                          텍스트로 주문서 복사
                        </button>
                      </div>

                      {/* 표 영역 */}
                      <div className="overflow-hidden border border-slate-100 rounded-2xl bg-white shadow-inner">
                        <table className="w-full border-collapse text-left text-xs">
                          <thead>
                            <tr className="bg-slate-50 border-b border-slate-100 text-slate-500 font-bold">
                              <th className="px-4 py-3 text-center w-12">
                                <input
                                  type="checkbox"
                                  className="rounded border-slate-300 text-teal-600 focus:ring-teal-500 cursor-pointer"
                                  checked={orderData.length > 0 && orderData.every(o => selectedOrderPIds.includes(o.pId))}
                                  onChange={(e) => {
                                    if (e.target.checked) {
                                      setSelectedOrderPIds(orderData.map(o => o.pId));
                                    } else {
                                      setSelectedOrderPIds([]);
                                    }
                                  }}
                                />
                              </th>
                              <th className="px-4 py-3">학년/학기</th>
                              <th className="px-4 py-3">교재명 (분류)</th>
                              <th className="px-4 py-3">학습 예정 원생 명단</th>
                              <th className="px-4 py-3 text-center w-24">주문 요구수량</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-50 font-medium">
                            {orderData.map(o => (
                              <tr 
                                key={o.pId} 
                                className={`hover:bg-slate-50/30 transition-colors ${selectedOrderPIds.includes(o.pId) ? 'bg-teal-50/20' : ''}`}
                              >
                                <td className="px-4 py-3.5 text-center">
                                  <input
                                    type="checkbox"
                                    className="rounded border-slate-300 text-teal-600 focus:ring-teal-500 cursor-pointer"
                                    checked={selectedOrderPIds.includes(o.pId)}
                                    onChange={() => {
                                      if (selectedOrderPIds.includes(o.pId)) {
                                        setSelectedOrderPIds(selectedOrderPIds.filter(id => id !== o.pId));
                                      } else {
                                        setSelectedOrderPIds([...selectedOrderPIds, o.pId]);
                                      }
                                    }}
                                  />
                                </td>
                                <td className="px-4 py-3.5 text-slate-600">
                                  <span className="inline-block px-2 py-0.5 bg-slate-100 rounded font-bold text-[10px] text-slate-600">
                                    {o.book.grade}
                                  </span>
                                  <div className="text-[10px] text-slate-400 mt-0.5">{o.book.category === '연산' ? '연산' : o.book.semester}</div>
                                </td>
                                <td className="px-4 py-3.5">
                                  <div className="text-slate-800 font-bold">{o.displayName}</div>
                                  <div className="text-[10px] text-indigo-600 mt-0.5">{o.book.category}</div>
                                </td>
                                <td className="px-4 py-3.5">
                                  <div className="flex flex-wrap gap-1 leading-normal">
                                    {o.studentNames.map(name => (
                                      <span key={name} className="bg-indigo-50/70 border border-indigo-100/50 text-indigo-700 px-1.5 py-0.5 rounded-md text-[10px] font-bold">
                                        {name}
                                      </span>
                                    ))}
                                  </div>
                                </td>
                                <td className="px-4 py-3.5 text-center">
                                  <div className="text-base font-black text-emerald-600 font-mono">
                                    {o.cnt} <span className="text-xs font-bold text-slate-400">부</span>
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>

                      {/* 선택된 교재 리스트 및 완료 버튼 */}
                      {selectedOrderPIds.length > 0 && (
                        <div className="p-4 bg-slate-50 border border-slate-150 rounded-2xl space-y-3 shadow-inner">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                              <span className="inline-block w-2.5 h-2.5 rounded-full bg-teal-500 animate-pulse" />
                              선택된 교재 요약 ({selectedOrderPIds.length}종 선택됨)
                            </span>
                            <button
                              type="button"
                              onClick={() => setSelectedOrderPIds([])}
                              className="text-[10px] font-bold text-slate-400 hover:text-slate-600 transition-colors"
                            >
                              선택 전체선택 해제
                            </button>
                          </div>

                          {/* Selected item list */}
                          <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto p-1 bg-white border border-slate-100 rounded-xl">
                            {orderData.filter(o => selectedOrderPIds.includes(o.pId)).map(o => (
                              <div key={o.pId} className="inline-flex items-center gap-1.5 px-2 bg-slate-50 border border-slate-150 hover:bg-slate-100/80 rounded-lg text-[10px] font-medium transition-colors py-1 shrink-0">
                                <span className="text-slate-500 font-bold">[{o.book.grade}]</span>
                                <span className="text-slate-800 font-bold">{o.displayName}</span>
                                <span className="bg-teal-100 border border-teal-200/50 text-teal-850 px-1.5 rounded font-black text-[9px]">{o.cnt}부</span>
                                <button
                                  type="button"
                                  onClick={() => setSelectedOrderPIds(selectedOrderPIds.filter(id => id !== o.pId))}
                                  className="text-slate-400 hover:text-slate-600 p-0.5 rounded transition-colors"
                                >
                                  <X className="w-3 h-3" />
                                </button>
                              </div>
                            ))}
                          </div>

                          <div className="pt-1 flex justify-end">
                            <button
                              type="button"
                              onClick={() => handleCompleteOrders(selectedOrderPIds)}
                              className="inline-flex items-center justify-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-teal-700 to-emerald-600 hover:from-teal-600 hover:to-emerald-500 text-white rounded-xl text-xs font-black shadow transition-all active:scale-95 cursor-pointer border border-teal-600/30"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                              선택된 교재주문 완료
                            </button>
                          </div>
                        </div>
                      )}

                      {/* 안내 메모 */}
                      <div className="text-[10px] text-slate-400 leading-normal text-right">
                        💡 예정 목록의 교재는, 선생님께서 개별 원아의 색칠판 진도표를 열어 해당 교재 카테고리 진도로 지정하여 학습을 개시시키면 학습예정 리스트에서 자동으로 사라집니다. 상단 체크박스로 개별 혹은 전체 교재를 선택해 <b>교재주문 완료</b> 처리를 하거나, 수동으로 즉시 삭제할 수도 있습니다.
                      </div>

                    </div>
                  );
                })()}
              </div>

              {/* Footer */}
              <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between shrink-0">
                <div className="text-xs text-slate-400 font-medium pl-2">
                  * 집계는 실시간 저장 데이터와 상시 연동됩니다.
                </div>
                <button
                  onClick={() => setIsOrderOpen(false)}
                  className="px-4.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow transition-all active:scale-95 cursor-pointer"
                >
                  확인
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
