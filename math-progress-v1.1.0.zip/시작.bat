@echo off
chcp 65001 >nul
title 초등 수학 진도 관리 - 실행기
cd /d "%~dp0"

echo ==========================================
echo    초등 수학 진도 관리 센터 - 실행기
echo ==========================================
echo.

REM ===== 1. 실행 프로그램(Node.js) 준비 =====
REM    프로그램에 내장된 node.exe 를 사용합니다. (별도 설치·인터넷 불필요)
set "NODE_EXE=%~dp0node\node.exe"
if not exist "%NODE_EXE%" (
    REM 내장 node 가 없으면 구버전 업데이트 등일 때 시스템 Node.js 로 대체
    where node >nul 2>nul
    if errorlevel 1 (
        echo [오류] 실행 프로그램 node.exe 을 찾을 수 없습니다.
        echo  프로그램 폴더 안의 node 폴더가 손상되었거나 삭제되었습니다.
        echo  원본 배포 폴더를 다시 받아주세요.
        echo.
        pause
        exit /b 1
    )
    echo [안내] 내장 node.exe 가 없어 시스템 Node.js 를 사용합니다.
    set "NODE_EXE=node"
)

REM ===== 2. 포트 3000 사용 여부 확인 =====
netstat -ano | findstr ":3000 " | findstr "LISTENING" >nul 2>nul
if errorlevel 1 goto portfree

REM 포트가 이미 열려 있으면 우리 프로그램인지 HTTP 200으로 확인
echo 포트 3000이 이미 사용 중입니다. 우리 프로그램인지 확인합니다...
for /f "delims=" %%c in ('curl -s -m 3 -o nul -w "%%{http_code}" http://127.0.0.1:3000/api/students') do set "SRV_CODE=%%c"
if "%SRV_CODE%"=="200" (
    echo 우리 프로그램 서버가 이미 실행 중입니다. 브라우저를 엽니다.
    start "" "http://localhost:3000"
    pause
    exit /b 0
)

REM 우리 서버가 아니면(충돌/다른 프로그램) 종료 후 재시작
echo [안내] 다른 프로그램이 포트 3000을 사용 중입니다.
echo  충돌을 막기 위해 해당 프로그램을 종료하고 다시 실행합니다.
call :killport3000

:portfree
REM ===== 3. 서버 실행 (컴파일된 프로덕션 빌드 - 내장 Node 사용) =====
echo 서버를 시작합니다...
echo  검은 창이 하나 더 열립니다. 끄면 프로그램도 종료됩니다.
echo.
set NODE_ENV=production
start "서버" cmd /k ""%NODE_EXE%" dist/server.cjs"

REM ===== 4. 서버가 준비되면 브라우저 자동 열기 =====
echo 브라우저를 자동으로 엽니다. 최대 60초 대기...
set /a tries=0
:waitloop
timeout /t 1 /nobreak >nul
set /a tries+=1
curl -s -o nul http://127.0.0.1:3000 >nul 2>nul
if not errorlevel 1 goto serverup
if %tries% LSS 60 goto waitloop
echo  서버 자동 시작에 실패했습니다. 주소창에 http://localhost:3000 을 입력하세요.
goto end

:serverup
start "" "http://localhost:3000"

:end
echo.
echo  프로그램이 실행 중입니다.
echo  종료하려면 검은 창을 닫으세요.
pause
exit /b 0

REM ===== 포트 3000 점유 프로그램 종료 =====
:killport3000
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":3000 " ^| findstr "LISTENING"') do taskkill /F /PID %%a >nul 2>nul
timeout /t 2 /nobreak >nul
goto :eof
