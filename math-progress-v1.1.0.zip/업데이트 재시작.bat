@echo off
chcp 65001 >nul
title 초등 수학 진도 관리 - 업데이트 적용 중...
cd /d "%~dp0"

echo ==========================================
echo    새 버전 적용 중입니다. 잠시만 기다려 주세요...
echo ==========================================
echo.

REM 1) 잠시 대기 후 기존 서버 종료 (HTTP 응답 전송 여유)
timeout /t 3 /nobreak >nul
echo [1/3] 기존 서버를 종료합니다...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":3000 " ^| findstr "LISTENING"') do taskkill /F /PID %%a >nul 2>nul
timeout /t 2 /nobreak >nul

REM 2) 새 파일 먼저 적용 (data/, node/, node_modules/, .git 등 제외 - 개인정보·데이터·실행환경 보호)
REM    ※ 컴파일 빌드(dist/)는 새 버전 서버 실행 파일이므로 반드시 복사됩니다.
REM    ※ 배포 빌드는 실행에 필요한 모든 라이브러리를 자체 포함하므로
REM      업데이트 시 별도 설치(npm install)가 필요 없습니다. (완전 오프라인)
echo [2/3] 새 버전 파일을 적용합니다...
if exist "업데이트_임시\new" (
    robocopy "업데이트_임시\new" . /E /XD data node node_modules .git 배포본 업데이트_임시 /NFL /NDL /NJH /NJS /NC /NS /NP
    if errorlevel 8 (
        echo [오류] 파일 적용 중 문제가 발생했습니다. 시작.bat 을 다시 실행해주세요.
        pause
        exit /b 1
    )
)

REM 임시 폴더 정리
rmdir /S /Q "업데이트_임시" >nul 2>nul

REM 3) 새 버전 서버 재기동 + 브라우저 열기 (내장 Node 사용 - 인터넷 불필요)
echo [3/3] 새 버전으로 서버를 시작합니다...
set NODE_ENV=production
set "NODE_EXE=%~dp0node\node.exe"
if not exist "%NODE_EXE%" set "NODE_EXE=node"
start "" cmd /k ""%NODE_EXE%" dist/server.cjs"

set /a tries=0
:waitloop
timeout /t 1 /nobreak >nul
set /a tries+=1
curl -s -o nul http://127.0.0.1:3000 >nul 2>nul
if not errorlevel 1 goto serverup
if %tries% LSS 60 goto waitloop
goto end

:serverup
start "" "http://localhost:3000"

:end
echo.
echo 업데이트 적용이 완료되었습니다!
exit /b 0
