@echo off
chcp 65001 >nul
title 초등 수학 진도 관리 - 업데이트 적용 중...
cd /d "%~dp0"

echo ==========================================
echo    새 버전 적용 중입니다. 잠시만 기다려 주세요...
echo ==========================================
echo.

REM 1) 잠시 대기 후 기존 서버 종료 (HTTP 응답 전송 여유)
timeout /t 3 /nobreak >nul
echo [1/4] 기존 서버를 종료합니다...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":3000 " ^| findstr "LISTENING"') do taskkill /F /PID %%a >nul 2>nul
timeout /t 2 /nobreak >nul

REM 2) 새 파일 먼저 적용 (data/, node_modules/, .git 등 제외 - 개인정보·데이터 보호)
REM    ※ 컴파일 빌드(dist/)는 새 버전 서버 실행 파일이므로 반드시 복사됩니다.
echo [2/4] 새 버전 파일을 적용합니다...
if exist "업데이트_임시\new" (
    robocopy "업데이트_임시\new" . /E /XD data node_modules .git 배포본 업데이트_임시 /NFL /NDL /NJH /NJS /NC /NS /NP
    if errorlevel 8 (
        echo [오류] 파일 적용 중 문제가 발생했습니다. 시작.bat 을 다시 실행해주세요.
        pause
        exit /b 1
    )
)

REM 3) 필요 시 의존성 재설치 (새 package.json 기준으로 설치해야 새 라이브러리가 반영됨)
if exist "업데이트_임시\need-install.flag" (
    echo [3/4] 새 버전의 필수 프로그램을 설치합니다...
    call npm install --no-audit --no-fund
    if errorlevel 1 (
        echo.
        echo [오류] 설치에 실패했습니다. 인터넷 연결을 확인 후 시작.bat 을 다시 실행해주세요.
        pause
        exit /b 1
    )
    del "업데이트_임시\need-install.flag" >nul 2>nul
) else (
    echo [3/4] 필수 프로그램 변경 없음 - 설치 생략
)

REM 임시 폴더 정리
rmdir /S /Q "업데이트_임시" >nul 2>nul

REM 4) 새 버전 서버 재기동 + 브라우저 열기 (컴파일된 프로덕션 빌드)
echo [4/4] 새 버전으로 서버를 시작합니다...
set NODE_ENV=production
start "" cmd /k "npm start"

set /a tries=0
:waitloop
timeout /t 1 /nobreak >nul
set /a tries+=1
curl -s -o nul http://127.0.0.1:3000 >nul 2>nul
if not errorlevel 1 goto serverup
if %tries% LSS 60 goto waitloop
goto end

:serverup
start "" "http://localhost:3000"

:end
echo.
echo 업데이트 적용이 완료되었습니다!
exit /b 0
